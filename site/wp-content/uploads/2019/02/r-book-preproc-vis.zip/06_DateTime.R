## ----setup, include=FALSE------------------------------------------------
if (!exists("linespread")) {
  linespread=1.2
  linespreadcode=1.1
  linespreadtable=1.0
}
knitr::opts_chunk$set(echo = TRUE)
library(lubridate)


## ---- results='hold'-----------------------------------------------------
dateNow <- Sys.Date()
print(dateNow)
class(dateNow)



## ---- results='hold'-----------------------------------------------------
timeNow <- Sys.time()
print(timeNow)
class(timeNow)


## ------------------------------------------------------------------------
unclass(dateNow); print.default(dateNow)
unclass(timeNow); print.default(timeNow)


## ---- include=F----------------------------------------------------------
linespread=1.11


## ---- include=F----------------------------------------------------------
#linespread=1.2
linespread=1.3


## ---- results='hold'-----------------------------------------------------
x <- Sys.time()

format(x, '%Y-%m-%d %H:%M:%S')
format(x, '%Y-%jT%H:%M:%S')
format(x, '%G-W%V-%u %H:%M:%S')


## ---- include=F----------------------------------------------------------
linespread=1.3
#linespread=1.2


## ------------------------------------------------------------------------
for (y in 2020:2027) 
  print(format(as.Date(paste0(y, '-01-01', sep='')), '%Y/%m/%d, V=%V U=%U u=%u w=%w A=%A a=%a'))


## ---- include=F----------------------------------------------------------
linespread=1.2


## ----include=F-----------------------------------------------------------
linespreadcode=1.05


## ----warning=FALSE, results='hold'---------------------------------------
library(parsedate)
as.Date('20210102', format='%Y%m%d'); as.Date(parse_iso_8601('20210102'))
as.Date('2021-01-02', format='%Y-%m-%d'); as.Date(parse_iso_8601('2021-01-02'))


## ----warning=FALSE, results='hold', tidy=FALSE---------------------------
as.Date('2021002', format='%Y%j'); as.Date(parse_iso_8601('2021002'))
as.Date('2021-002', format='%Y-%j'); as.Date(parse_iso_8601('2021-002'))


## ----warning=FALSE, results='hold'---------------------------------------
as.Date(parse_iso_8601('2020W536'))
as.Date(parse_iso_8601('2020-W53-6'))


## ----include=F-----------------------------------------------------------
load('linespreadcode.RData')


## ---- results='hold'-----------------------------------------------------
library(magrittr)
as.Date('Jan 01 2020', format='%b %d %Y')
as.Date('January 01 2020', format='%B %d %Y')
Sys.getlocale("LC_ALL") %>% strsplit(";")

## ---- results='hold'-----------------------------------------------------
Sys.setlocale("LC_ALL", "English") %>% strsplit(";")
as.Date('Jan 01 2020', format='%b %d %Y')
as.Date('January 01 2020', format='%B %d %Y')

## ---- eval=FALSE---------------------------------------------------------
## Sys.setlocale("LC_ALL", "Korean") %>% strsplit(";")

## ---- include=FALSE------------------------------------------------------
Sys.setlocale("LC_ALL", "Korean") %>% strsplit(";")


## ---- results='hold'-----------------------------------------------------
as.Date('March 01 2020', format='%B %d %Y')
# Mars is the 3rd month of the year in French
as.Date('Mars 01 2020', format='%B %d %Y') 


## ---- results='hold'-----------------------------------------------------
mdy('March 01 2020')
mdy('Mars 01 2020', locale='French')
Sys.setlocale("LC_ALL", "French") %>% strsplit(";")


## ---- results='hold'-----------------------------------------------------
as.Date('Mars 01 2020', format='%B %d %Y')
as.Date('March 01 2020', format='%B %d %Y')
mdy('March 01 2020')
mdy('Mars 01 2020')

## ---- results='hold'-----------------------------------------------------
Sys.setlocale("LC_ALL", "Korean") %>% strsplit(";")
mdy('Mars 01 2020', locale='French_France.1252')


## ---- results='hold'-----------------------------------------------------
wday(today(), label = TRUE, abbr = FALSE, locale = "German")
wday(today(), label = TRUE, abbr = FALSE, locale = "French")
month(today(), label = TRUE, abbr = FALSE, locale = "German")
month(today(), label = TRUE, abbr = FALSE, locale = "French")


## ---- results='hold'-----------------------------------------------------
Sys.setlocale("LC_ALL", "English") %>% strsplit(";")
as.POSIXct('March 01 2020 11:13:22', format='%B %d %Y %H:%M:%S')
strptime('March 01 2020 11:13:22', format='%B %d %Y %H:%M:%S')
mdy_hms('March 01 2020 11:13:22')
mdy_hms('March 01 2020 11:13:22', tz='Asia/Seoul')


## ---- results='hold'-----------------------------------------------------
Sys.setlocale("LC_ALL", "French") %>% strsplit(";")
as.POSIXct('Mars 01 2020 11:13:22', format='%B %d %Y %H:%M:%S')
strptime('Mars 01 2020 11:13:22', format='%B %d %Y %H:%M:%S')
mdy_hms('Mars 01 2020 11:13:22')
mdy_hms('Mars 01 2020 11:13:22', tz='Asia/Seoul')

Sys.setlocale("LC_ALL", "Korean") %>% strsplit(";")


## ----error=T, results='hold'---------------------------------------------
t0 <- Sys.time()
t1 <- as.POSIXct("2030-01-01 00:00:00")
t1-t0
difftime(t1, t0, units='weeks')
difftime(t1, t0, units='hours')


## ----error=T, results='hold'---------------------------------------------
t0s <- format(t0, format="%Y-%m-%d %H:%S:%M")
t1s <- format(t1, format="%Y-%m-%d %H:%S:%M")
t1s-t0s
difftime(t1s, t0s, units='weeks')
difftime(t1s, t0s, units='hours')


## ----error=T, results='hold'---------------------------------------------
t0s <- format(t0, format="%m-%m-%Y %H:%S:%M")
t1s <- format(t1, format="%m-%m-%Y %H:%S:%M")
t1s-t0s
difftime(t1s, t0s, units='weeks')
difftime(t1s, t0s, units='hours')


## ---- include=F----------------------------------------------------------
linespread=1.45


## ----error=T, results='hold', tidy=FALSE---------------------------------
t <- Sys.time()
t
year(t); year(t) <- 2030; t
month(t); month(t) <- 1; t
week(t); week(t) <- 2; t
day(t); day(t) <- 2; t


## ----error=T, results='hold', tidy=FALSE---------------------------------
yday(t); yday(t) <- 1; t
yday(t); yday(t) <- 366; t
mday(t); mday(t) <- 2; t # same as day(t)
wday(t); wday(t) <- 3; t
wday(t, label=TRUE); wday(t); 
wday(t) <- 1; t 


## ----error=T, results='hold', tidy=FALSE---------------------------------
hour(t); hour(t) <- 12; t
minute(t); minute(t) <- 41; t
second(t); second(t) <- 12; t
tz(t) ; tz(t) <- "GMT"; t
dst(t); dst(t) <- TRUE; t # Daylight Saving Time


## ---- collapse=TRUE, tidy=FALSE, results='hold'--------------------------
format(as.Date(parse_iso_8601('2020-W53-6')), "%A")
# 'lubridate.week.start'=1이면 
#월=1, 화=2, 수=3, 목=4, 금=5, 토=6, 일=7
options('lubridate.week.start'=1) 
wday(as.Date(parse_iso_8601('2020-W53-6'))) 
# 'lubridate.week.start'=2이면 
# 화(2)=1, 수=2, 목=3, 금=4, 토=5, 일=6, 월=7
options('lubridate.week.start'=2) 
wday(as.Date(parse_iso_8601('2020-W53-6')))


## ---- results='hold'-----------------------------------------------------
t <- Sys.time()
t
tz(t) <- "GMT" # 또는 force_tz(t, tzone="GMT")
t
with_tz(t, "Asia/Seoul")


## ---- include=F----------------------------------------------------------
linespread=1.4


## ---- results='hold', tidy=FALSE-----------------------------------------
t0 <- as.POSIXct("2021-01-01 13:00:00", tz='Europe/Paris'); t0
t1 <- t0; tz(t1) <- "Asia/Seoul"; t1
t2 <- with_tz(t1, tzone='Europe/Paris'); t2
t3 <- t2; hour(t3) <- hour(t3) + 7; t3
t4 <- with_tz(t3, tzone='Asia/Seoul'); t4


## ---- results='hold'-----------------------------------------------------
print(t1)
print(t2)
t1 == t2


## ---- include=F----------------------------------------------------------
linespread=1.2

