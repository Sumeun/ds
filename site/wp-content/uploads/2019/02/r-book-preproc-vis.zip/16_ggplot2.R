## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

knitr::opts_chunk$set(out.width='55%')
knitr::opts_chunk$set(fig.width=3.7)
knitr::opts_chunk$set(fig.height=2.78)

knitr::opts_chunk$set(fig.show='hold')
knitr::opts_chunk$set(fig.align='default')

knitr::opts_chunk$set(tidy.opts=list(width.cutoff=72, indent = 2), tidy = FALSE)
library(ggplot2)
library(dplyr)

# List of .Rmds
# ggplot2_intro.Rmd
# ggplot2_aes.Rmd
# ggplot2_geoms.Rmd
# ggplot2_coord.Rmd
# ggplot2_legend.Rmd
# ggplot2_title.Rmd
# ggplot2_summary.Rmd
o <- options("max.print")
options(max.print=10)


## ------------------------------------------------------------------------
data(mpg, package='ggplot2')


## ---- fig.align='center'-------------------------------------------------
ggplot(data=mpg, aes(x=displ, y=hwy)) + geom_point()


## ---- eval=F-------------------------------------------------------------
## ggplot(data= , aes(x=  , y=   , col=  , size=  , shape=   )) +
##   geom_point()


## ---- eval=F-------------------------------------------------------------
## ggplot(data, aes(x=  , y=   , col=  , size=  , shape=   )) +
##   geom_point() +
##   geom_line()


## ---- eval=F-------------------------------------------------------------
## ggplot(data, aes(x=  , y=   , col=  , size=  , shape=   )) +
##   geom_point() +
##   geom_line() +
##   geom_smooth(method='lm/glm/gam/loess/MASS::rlm', span=  , formula=  )


## ----eval=F, warning=FALSE-----------------------------------------------
## # 자동차 연비(1999-2008)
## ggplot(mpg, aes(x=class, y=cty)) + geom_point()
## ggplot(mpg, aes(x=class, y=cty)) + geom_jitter(width=0.2)
## ggplot(mpg, aes(x=class, y=cty)) + geom_boxplot()
## ggplot(mpg, aes(x=class, y=cty)) + geom_violin()

## ----echo=F, warning=FALSE-----------------------------------------------
ggplot(mpg, aes(x=class, y=cty)) + geom_point() +
  labs(subtitle = '+ geom_point()')
ggplot(mpg, aes(x=class, y=cty)) + geom_jitter(width=0.2) + 
  labs(subtitle = '+ geom_jitter(width=0.2)')
ggplot(mpg, aes(x=class, y=cty)) + geom_boxplot() +
  labs(subtitle = '+ geom_boxplot()')
ggplot(mpg, aes(x=class, y=cty)) + geom_violin() + 
  labs(subtitle = '+ geom_violin()')


## ---- eval=F-------------------------------------------------------------
## ggplot(data = , aes(x= )) + geom_histogram(bins=  , binwidth=  , breaks=  )
## ggplot(data = , aes(x= )) + geom_freqpoly(bins=  , binwidth=  , breaks=  )


## ---- eval=F-------------------------------------------------------------
## ggplot(data = mpg, aes(x=cty)) + geom_histogram(bins= 30)
## ggplot(data = mpg, aes(x=cty)) + geom_freqpoly(bins= 30)

## ----echo=FALSE, message=FALSE, warning=FALSE, paged.print=FALSE---------
ggplot(data = mpg, aes(x=cty)) + geom_histogram(bins= 30) + labs(subtitle=' + geom_histogram(bins=30)')
ggplot(data = mpg, aes(x=cty)) + geom_freqpoly(bins= 30) + labs(subtitle=' + geom_frequency(bins=30)') 


## ---- eval=F-------------------------------------------------------------
## ggplot(data = mpg, aes(x=cty)) + geom_histogram(binwidth= 5)
## ggplot(data = mpg, aes(x=cty)) + geom_freqpoly(binwidth= 5)

## ---- echo=F-------------------------------------------------------------
ggplot(data = mpg, aes(x=cty)) + geom_histogram(binwidth= 5) + 
  labs(subtitle = '+ geom_histogram(binwidth=5)')
ggplot(data = mpg, aes(x=cty)) + geom_freqpoly(binwidth= 5) +
  labs(subtitle = '+ geom_freqpoly(binwidth=5)')


## ---- eval=F-------------------------------------------------------------
## ggplot(data = mpg, aes(x=cty)) + geom_histogram(breaks= c(0,5,10,15:25,45))
## ggplot(data = mpg, aes(x=cty)) + geom_freqpoly(breaks= c(0,5,10,15:25,45))

## ---- echo=FALSE---------------------------------------------------------
ggplot(data = mpg, aes(x=cty)) + geom_histogram(breaks= c(0,5,10,15:25,45)) + 
  labs(subtitle='+ geom_histogram(breaks=c(0,5,10,15:25,45))')
ggplot(data = mpg, aes(x=cty)) + geom_freqpoly(breaks= c(0,5,10,15:25,45)) + 
  labs(subtitle='+ geom_freqpoly(breaks=c(0,5,10,15:25,45))')


## ---- eval=F, tidy=FALSE-------------------------------------------------
## ggplot(data=mpg, aes(x=class)) + geom_bar(col='blue', fill='red')
## #ggplot(data=mpg, aes(x=class)) + geom_bar(aes(col='blue', fill='red'))라고
## #쓰지 않도록 조심하자.
## #aes는 자료와 시각적 특성을 대응시키고,
## #aes없이 col= 또는 fill=을 쓰면 데이터에 상관없이 색깔과 채움색을 정하는 것이다.

## ---- echo=F-------------------------------------------------------------
ggplot(data=mpg, aes(x=class)) + geom_bar(col='blue', fill='red') + 
  labs(subtitle="+ geom_bar(col='blue', fill='red')")


## ---- eval=F-------------------------------------------------------------
## data(mpg, package='ggplot2')
## dat <- table(mpg$class)
## df <- as.data.frame(dat)
## colnames(df) = c('name', 'n')
## print(head(df))
## ggplot(df, aes(x=name, y=n)) + geom_bar(stat='identity')
## ggplot(df, aes(x=name, y=n)) + geom_col()

## ---- echo=F, warning=FALSE----------------------------------------------
data(mpg, package='ggplot2')
dat <- table(mpg$class)
df <- as.data.frame(dat)
colnames(df) = c('name', 'n')
print(head(df))
ggplot(df, aes(x=name, y=n)) + geom_bar(stat='identity') + 
  labs(subtitle="+ geom_bar(stat='identity')")
ggplot(df, aes(x=name, y=n)) + geom_col() + 
  labs(subtitle="+ geom_col()")


## ---- tidy=FALSE, eval=F-------------------------------------------------
## g <- ggplot(mpg, aes(x = fl, fill= fl)) + geom_bar()
## g
## g + scale_fill_manual(
##   values = c("orange", "skyblue", "royalblue", "blue", "navy"))
## g + scale_fill_manual(
##   values = c("orange", "skyblue", "royalblue", "blue", "navy"),
##   breaks = c("e", "p"))
## g + scale_fill_manual(
##   values = c("orange", "skyblue", "royalblue", "blue", "navy"),
##   breaks = c('e', 'p'),
##   labels = c("Ethanol", "Premium"))
## g + scale_fill_manual(
##   values = c("orange", "skyblue", "royalblue", "blue", "navy"),
##   breaks = c('e', 'p'),
##   labels = c("Ethanol", "Premium"),
##   name = "fuel type")
## g + scale_fill_manual(
##   values = c("orange", "skyblue", "royalblue", "blue", "navy"),
##   limits = c('e', 'p'),
##   breaks = c('e', 'p'),
##   labels = c("Ethanol", "Premium"),
##   name = "fuel type")

## ---- echo=F-------------------------------------------------------------
g <- ggplot(mpg, aes(x = fl, fill= fl)) + geom_bar() 
g + labs(subtitle=' ')
g + scale_fill_manual(
  values = c("orange", "skyblue", "royalblue", "blue", "navy")) +
  labs(subtitle="+ scale_fill_manual(values = c(\"orange\", \"skyblue\", \"royalblue\", \"blue\", \"navy\"))")
g + scale_fill_manual(
  values = c("orange", "skyblue", "royalblue", "blue", "navy"),
  breaks = c("e", "p")) + 
  labs(subtitle='+ scale_fill_manual(breaks=c("e", "p"))')
g + scale_fill_manual(
  values = c("orange", "skyblue", "royalblue", "blue", "navy"),
  breaks = c('e', 'p'),
  labels = c("Ethanol", "Premium")) + 
  labs(subtitle='+ scale_fill_manual(labels = c("Ethanol", "Premium"))')
g + scale_fill_manual(
  values = c("orange", "skyblue", "royalblue", "blue", "navy"),
  breaks = c('e', 'p'),
  labels = c("Ethanol", "Premium"),
  name = "fuel type") + 
  labs(subtitle='+ scale_fill_manual(name = "fuel type")')
g + scale_fill_manual(
  values = c("orange", "skyblue", "royalblue", "blue", "navy"),
  limits = c('e', 'p'),
  breaks = c('e', 'p'),
  labels = c("Ethanol", "Premium"),
  name = "fuel type") + 
  labs(subtitle = '+ scale_fill_manual(limits = c("e", "p"))')


## ----warning=FALSE, eval=F-----------------------------------------------
## mpg$yr = as.Date(as.character(mpg$year), "%Y")
## mpg2 <- mpg %>% filter(manufacturer %in% c("audi", "dodge", "ford", "jeep"))
## ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) +
##   geom_jitter() +
##   scale_x_date(date_labels="%Y")
## ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) +
##   geom_jitter() +
##   scale_x_date(date_labels="%y-%m")
## ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) +
##   geom_jitter() +
##   scale_x_date(date_labels="%y",
##                date_breaks="1 year")
## ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) +
##   geom_jitter() +
##   scale_x_date(date_labels="%y",
##                date_breaks="2 years")

## ----warning=FALSE, echo=F-----------------------------------------------
mpg$yr = as.Date(as.character(mpg$year), "%Y")
mpg2 = mpg %>% filter(manufacturer %in% c("audi", "dodge", "ford", "jeep"))
ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) + 
  geom_jitter() + labs(subtitle = '+ scale_x_date(date_labels="%Y")') +
  scale_x_date(date_labels="%Y")
ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) + 
  geom_jitter() + labs(subtitle = '+ scale_x_date(date_labels="%y-%m")') +
  scale_x_date(date_labels="%y-%m")
ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) + 
  geom_jitter() + 
  scale_x_date(date_labels="%y",
               date_breaks="1 year") +
  labs(subtitle='+ scale_x_date(date_labels="%y",
  date_breaks="1 year")')
ggplot(mpg2, aes(x=yr, y=displ, col=manufacturer)) + 
  geom_jitter() + 
  scale_x_date(date_labels="%y",
               date_breaks="2 years") + labs(subtitle='+ scale_x_date(date_labels="%y",
  date_breaks="2 years")')


## ---- eval=F, tidy=FALSE-------------------------------------------------
## g <- ggplot(mpg, aes(x=displ, y=hwy, col=drv)) +
##   geom_jitter()
## g
## g + scale_color_manual(values=c('red','orange', 'blue','navy'))
## g + scale_color_grey(start=0.2, end=0.8, na.value='red')
## g + scale_color_brewer(palette = "Dark2")

## ----echo=FALSE----------------------------------------------------------
g <- ggplot(mpg, aes(x=displ, y=hwy, col=drv)) + 
  geom_jitter() 
g + labs(title=' ')
g + scale_color_manual(values=c('red','orange', 'blue')) + labs(title='+ scale_color_manual()')
g + scale_color_grey(start=0.2, end=0.8, na.value='red') + labs(title='+ scale_color_grey(start=0.2, end=0.8, na.value="red")')
g + scale_color_brewer(palette = "Dark2") + labs(title='+ scale_color_brewer(palette="Dark2")')


## ----include=F-----------------------------------------------------------
fig.height=8.96

## ----eval=F, include=F, fig.align='center', out.width='80%', fig.width=5.376, fig.height=6.96----
## RColorBrewer::display.brewer.all()

## ---- eval=F-------------------------------------------------------------
## RColorBrewer::display.brewer.all()


## ---- include=F, eval=F--------------------------------------------------
## #* 위의 팔레트 중에서 범주형 자료를 나타내는 데 적합한 팔레트와 순위형 자료를 나타내는 데 적합한 팔레트는 무엇일까?


## ---- include=F----------------------------------------------------------
if (file.exists("palette.RData")) {
  load(file='palette.RData')
} else {
  pal <- choose_palette()
  save(pal, file="palette.RData")
}

## ---- eval=FALSE---------------------------------------------------------
## pal <- choose_palette()


## ---- include=F----------------------------------------------------------
###![](ChooseColorPalette.png)


## ---- eval=FALSE---------------------------------------------------------
## g + scale_color_manual(values=pal(3))

## ---- echo=FALSE---------------------------------------------------------
g + scale_color_manual(values=pal(3)) + labs(subtitle='+ scale_color_manual(values=pal(3))')


## ---- eval=FALSE---------------------------------------------------------
## if (file.exists("palette.RData")) {
##   load(file='palette.RData')
## } else {
##   pal <- choose_palette()
##   save(pal, file="palette.RData")
## }


## ---- eval=F, tidy=FALSE-------------------------------------------------
## library(colorspace)
## g + scale_color_discrete_qualitative(palette='Dark3')
## g + scale_color_discrete_diverging(palette='Berlin')

## ----echo=FALSE----------------------------------------------------------
library(colorspace)
g + scale_color_discrete_qualitative(palette='Dark3') +
  labs(subtitle="+scale_color_discrete_qualitative(palette='Dark3')")
g + scale_color_discrete_diverging(palette='Berlin') +
  labs(subtitle="+scale_color_discrete_diverging(palette='Berlin')")


## ----message=TRUE, warning=TRUE, include=FALSE---------------------------
library(colorspace)
fnpdf <- 'hcl_palettes_multihue.pdf'
if (!file.exists(fnpdf)) {
#if (F) {
  pdf(fnpdf, width=6.57, height=6.93) # 167mm(width), 176mm(height)
  hcl_palettes("sequential (multi-hue)", n = 7, plot = TRUE)
  dev.off() }


## ----message=TRUE, warning=TRUE, include=FALSE---------------------------
library(colorspace)
fnpdf <- 'hcl_palettes_multihue_small.pdf'
if (!file.exists(fnpdf)) {
#if (F) {
  pdf(fnpdf, width=6.57, height=3.465) # 167mm(width), 176mm(height)/2
  hcl_palettes("sequential (multi-hue)", n = 7, plot = TRUE)
  dev.off() }


## ---- eval=FALSE---------------------------------------------------------
## hcl_palettes(plot = TRUE)


## ---- eval=F-------------------------------------------------------------
## h <- ggplot(mpg, aes(x=displ, y=hwy)) + geom_jitter(alpha=0.5)
## h
## h + scale_x_reverse()
## h + scale_x_sqrt()
## h + scale_y_log10(breaks=seq(10,50,10),
##                   limits = c(20,40),
##                   labels=c('ten', 'twenty','thirty', 'fourty','fifty'),
##                   name='highway(miles/gallon)')

## ---- echo=F-------------------------------------------------------------
#g + scale_y_log10() + labs(title='+ scale_y_log10()')
h <- ggplot(mpg, aes(x=displ, y=hwy)) + geom_jitter(alpha=0.5) 
h + labs(subtitle=' ')
#h + scale_y_log10(breaks=seq(10, 50, 10)) + labs(title='+ scale_y_log10(breaks=seq(10, 50, 0.1))')
h + scale_x_reverse() + labs(subtitle = '+ scale_x_reverse()')
h + scale_x_sqrt() + labs(subtitle = '+ scale_x_sqrt()')
h + scale_y_log10(breaks=seq(10,50,10),
                  limits = c(20,40),
                  labels=c('ten', 'twenty','thirty', 'fourty','fifty'),
                  name='highway(miles/gallon)') + 
  labs(subtitle="+ scale_y_log10(breaks=seq(10,50,10),
limits = c(20,40),
labels=c('ten', 'twenty','thirty', 'fourty','fifty'),
name='highway(miles/gallon)')")


## ----warning=FALSE, eval=F-----------------------------------------------
## t <- ggplot(mpg, aes(cty, hwy)) + geom_point()
## t
## t + facet_grid(. ~ drv)
## t + facet_grid(drv ~ .)
## t + facet_grid(year ~ drv)
## t + facet_grid(.~ drv + year)
## t + facet_grid(drv + year ~ .)
## t + facet_wrap(~ drv)
## t + facet_wrap(~ drv + year)

## ----warning=FALSE, echo=F-----------------------------------------------
t <- ggplot(mpg, aes(cty, hwy)) + geom_point() + labs(title=' ')
t + labs(subtitle=' ')
t + facet_grid(. ~ drv) + labs(subtitle='+ facet_grid(. ~ drv)')
t + facet_grid(drv ~ .) + labs(subtitle='+ facet_grid(drv ~ .)')
t + facet_grid(year ~ drv) + labs(subtitle='+ facet_grid(year ~ drv)')
t + facet_grid(.~ drv + year) + labs(subtitle='+ facet_grid(.~ drv + year)')
t + facet_grid(drv + year ~ .) + labs(subtitle='+ facet_grid(drv + year ~ .)')
t + facet_wrap(~ drv) + labs(subtitle='+ facet_wrap(~ drv)')
t + facet_wrap(~ drv + year) + labs(subtitle='+ facet_wrap(~ drv + year)')


## ---- warning=FALSE, eval=FALSE------------------------------------------
## t + facet_grid(drv ~ year, scales = "free")
## t + facet_grid(drv ~ year, scales = "free_x")
## t + facet_grid(drv ~ year, scales = "free_y")

## ---- warning=FALSE, echo=FALSE------------------------------------------
t + facet_grid(drv ~ year, scales = "free") + labs(subtitle='+ facet_grid(drv ~ year, scales = "free")')
t + facet_grid(drv ~ year, scales = "free_x") + labs(subtitle='+ facet_grid(drv ~ year, scales = "free_x")')
t + facet_grid(drv ~ year, scales = "free_y") + labs(subtitle='+ facet_grid(drv ~ year, scales = "free_y")')


## ----warning=FALSE, eval=FALSE-------------------------------------------
## t
## t + facet_grid(drv ~ ., labeller = label_both)
## t + facet_grid(drv ~ ., labeller = label_bquote(alpha ^ .(drv)))

## ----warning=FALSE, echo=FALSE, fig.height=2.4---------------------------
t + labs(subtitle=' ')
t + facet_grid(drv ~ ., labeller = label_both) + labs(subtitle='labeller = label_both')
t + facet_grid(drv ~ ., labeller = label_bquote(alpha ^ .(drv))) + labs(subtitle='labeller = label_bquote(alpha ^ .(drv))')
#t + facet_grid(drv ~ drv, labeller = label_parsed) + labs(subtitle='labeller = label_parsed')


## ---- fig.align='center', echo=FALSE, fig.width=2.1, fig.height=1.2, out.width='30%'----
#out.width='30%'
#d = data.frame(shape=factor(c('1st', '2nd', '3rd', '4th', '5th', '6th')))
#ggplot(data=d, aes(x=1:6, y=0, shape=shape)) + geom_point() + theme_minimal() 

d=data.frame(x=1:6, p=c(16,17,15, 3,7,8), l=c('1st', '2nd', '3rd', '4th', '5th', '6th'))
ggplot() +
  scale_y_continuous(name="", breaks=0, labels=rep("",1)) +
  scale_x_continuous(name="", breaks=0:6, labels=rep('',7)) +
  coord_cartesian(ylim=c(-1, 1)  ) +
  scale_shape_identity() +
  #coord_fixed(ratio=1) + 
  geom_point(data=d, mapping=aes(x=x%%10, y=x%/%10, shape=p), size=5, fill="red") +
  #geom_text(data=d, mapping=aes(x=x%%10, y=x%/%10+0.3, label=p), size=3) +
  #geom_text(data=d, mapping=aes(x=x%%10, y=x%/%10-0.3, label=l), size=3) +
  #geom_text(x=0, y=+0.3, label='shape value') + 
  #geom_text(x=0, y=-0.3, label='factor number') + 
  theme_minimal()
# 16, 17, 15, 3, 7, 8?


## ----echo=FALSE, fig.align='center', fig.height=1.990, fig.width=5.376, out.width="80%"----
d=data.frame(p=c(0:25))
ggplot() +
  scale_y_continuous(name="", breaks=0:2, labels=rep("",3)) +
  scale_x_continuous(name="", breaks=0:9, labels=rep('',10)) +
  coord_cartesian(ylim=c(-0.3, 2.5)) +
  scale_shape_identity() +
  geom_point(data=d, mapping=aes(x=p%%10, y=p%/%10, shape=p), size=5, fill="red") +
  geom_text(data=d, mapping=aes(x=p%%10, y=p%/%10+0.4, label=p), size=3) +
  theme_minimal()
#  fig.width=5.376, out.width="80%" -> 90mm, 40mm  = 5.376*2.390
#  fig.height=1.792 -> 아래 짤리 y coordinate을 -0.5부터

## ---- eval=F, include=F--------------------------------------------------
## 5.376*10/8=6.72


## ---- eval=F, tidy=FALSE, error=T----------------------------------------
## mpg4 <- mpg %>% filter(manufacturer %in%
##         c('audi', 'dodge', 'ford', 'honda', 'hyundai', 'jeep', 'toyota'))
## g <- ggplot(mpg4, aes(x=displ, y=hwy, shape=manufacturer)) +
##   geom_jitter()
## g
## g + scale_shape_manual(values=c(1,2,3,4,15,16,17))
## g + scale_shape_manual(values=c(1,2,3,4,15,16,17),
##                        breaks=c('audi', 'dodge', 'ford'))
## g + scale_shape_manual(limits=c('audi','dodge','ford'),
##                        values=c(1,2,3),
##                        breaks=c('audi', 'dodge', 'ford'))

## ---- echo=F, tidy=FALSE-------------------------------------------------
mpg4 <- mpg %>% filter(manufacturer %in% 
        c('audi', 'dodge', 'ford', 'honda', 'hyundai', 'jeep', 'toyota'))
g <- ggplot(mpg4, aes(x=displ, y=hwy, shape=manufacturer)) + 
  geom_jitter() 
g + labs(subtitle=" ")
g + scale_shape_manual(values=c(1,2,3,4,15,16,17)) + 
  labs(subtitle="+ scale_shape_manual(values=c(1,2,3,4,15,16,17))")
g + scale_shape_manual(values=c(1,2,3,4,15,16,17),
                       breaks=c('audi', 'dodge', 'ford')) + 
  labs(subtitle="
+ scale_shape_manual(values=c(1,2,3,4,15,16,17)),
  breaks=c('audi', 'dodge', 'ford'))")
g + scale_shape_manual(limits=c('audi','dodge','ford'),
                       values=c(1,2,3),
                       breaks=c('audi', 'dodge', 'ford')) + 
  labs(subtitle="+ scale_shape_manual(limits=c('audi','dodge','ford'),
  values=c(1,2,3),
  breaks=c('audi', 'dodge', 'ford'))")


## ----eval=F, message=FALSE, warning=FALSE--------------------------------
## c <- ggplot(mpg, aes(x = hwy))
## c + geom_histogram(binwidth = 5)
## c + geom_area(stat = "bin")
## c + geom_density(kernel = "gaussian")
## c + geom_dotplot(binwidth=0.6)
## c + geom_freqpoly()
## ggplot(mpg) + geom_qq(aes(sample=hwy))

## ----echo=FALSE, message=FALSE, warning=FALSE----------------------------
c <- ggplot(mpg, aes(x = hwy))
c + geom_histogram(binwidth = 5) + labs(title='+ geom_histogram(binwidth = 5)')
c + geom_area(stat = "bin") + labs(title='+ geom_area(stat = "bin")')
c + geom_density(kernel = "gaussian") + labs(title='+ geom_density(kernel = "gaussian")')
c + geom_dotplot(binwidth=0.6) + labs(title='+ geom_dotplot(binwidth=0.6)')
c + geom_freqpoly() + labs(title='+ geom_freqpoly()')
c2 <- ggplot(mpg)
c2 + geom_qq(aes(sample=hwy)) + labs(title='+ geom_qq(aes(sample=hwy))')


## ---- eval=F-------------------------------------------------------------
## d <- ggplot(mpg, aes(fl))
## d + geom_bar()

## ---- echo=F-------------------------------------------------------------
d <- ggplot(mpg, aes(fl))
d + geom_bar() + labs(title='+ geom_bar()')


## ---- eval=F, tidy=FALSE-------------------------------------------------
## e <- ggplot(mpg, aes(cty, hwy))
## e + geom_label(aes(label = cty), nudge_x = 1, nudge_y = 1)
## e + geom_jitter(height = 2, width = 2)
## e + geom_point()
## e + geom_quantile()
## e + geom_rug(sides = "bl")
## e + geom_smooth(method = lm)
## e + geom_text(aes(label = cty),
##               nudge_x = 1, nudge_y = 1, check_overlap = TRUE)

## ----echo=F, message=FALSE, warning=FALSE--------------------------------
e <- ggplot(mpg, aes(cty, hwy))
e + geom_label(aes(label = cty), nudge_x = 1, nudge_y = 1) + labs(subtitle='+ geom_label(aes(label = cty), nudge_x = 1, nudge_y = 1)')
e + geom_jitter(height = 2, width = 2) + labs(subtitle='+ geom_jitter(height = 2, width = 2)') 
e + geom_point() + labs(subtitle='+ geom_point()')
e + geom_quantile() + labs(subtitle='+ geom_quantile()')
e + geom_rug(sides = "bl") + labs(subtitle='+ geom_rug(sides = "bl")')
e + geom_smooth(method = lm) + labs(subtitle='+ geom_smooth(method = lm)')
e + geom_text(aes(label = cty), nudge_x = 1, nudge_y = 1, check_overlap = TRUE) + labs(subtitle='+ geom_text(aes(label = cty),
  nudge_x = 1, nudge_y = 1, 
  check_overlap = TRUE)')


## ---- eval=F, fig.align='center', tidy=FALSE-----------------------------
## e1 <- e + geom_jitter(height=2, width=2, alpha=0.5, size=2) +
##   geom_quantile(quantiles=c(0.05, 0.95)) +
##   geom_rug(sides = 'tr') # top, bottom, left, right
## e1 + geom_smooth(method=lm, size=2);
## e1 + geom_smooth(method=lm, size=2, se=FALSE); # 신뢰구간 없음

## ----echo=F, message=FALSE, warning=FALSE, tidy=FALSE--------------------
e + geom_jitter(height=2, width=2, alpha=0.5, size=2) +
  geom_quantile(quantiles=c(0.05, 0.95)) + 
  geom_rug(sides = 'tr') +  # top, bottom, left, right
  geom_smooth(method=lm, size=2) +  # 만약 신뢰구간을 보기 싫다면 se = F +
  labs(subtitle = '+ geom_jitter(height=2, width=2, alpha=0.5, size=2) +
geom_quantile(quantiles=c(0.05, 0.95)) +
geom_rug(sides = \'tr\') +
geom_smooth(method=lm, size=2)')
e + geom_jitter(height=2, width=2, alpha=0.5, size=2) +
  geom_quantile(quantiles=c(0.05, 0.95)) + 
  geom_rug(sides = 'tr') +  # top, bottom, left, right
  geom_smooth(method=lm, size=2, se=FALSE) +  # 만약 신뢰구간을 보기 싫다면 se = F +
  labs(subtitle = '+ geom_jitter(height=2, width=2, alpha=0.5, size=2) +
geom_quantile(quantiles=c(0.05, 0.95)) +
geom_rug(sides = \'tr\') +
geom_smooth(method=lm, size=2, se=F)')


## ---- eval=F-------------------------------------------------------------
## e2 <- e + geom_jitter(height=2, width=2, alpha=0.5, size=2) +
##   geom_rug(sides = 'tr')  # top, bottom, left, right
## e2 + geom_quantile(method='rqss')
## e2 + geom_quantile(method='rqss', lambda = 10)
## # geom_quantile(method='rqss', quantiles=c(0.05, 0.95))을 사용하여 신뢰구간을 변경한다.

## ----echo=F, message=FALSE, warning=FALSE--------------------------------
e + geom_jitter(height=2, width=2, alpha=0.5, size=2) +
  geom_rug(sides = 'tr') +  # top, bottom, left, right
  geom_quantile(method='rqss') + labs(subtitle='+ geom_jitter(height=2, width=2, alpha=0.5, size=2) +
geom_rug(sides = \'tr\') +
geom_quantile(method=\'rqss\')')
e + geom_jitter(height=2, width=2, alpha=0.5, size=2) +
  geom_rug(sides = 'tr') +  # top, bottom, left, right
  geom_quantile(method='rqss', lambda=3) + labs(subtitle='+ geom_jitter(height=2, width=2, alpha=0.5, size=2) +
geom_rug(sides = \'tr\') +
geom_quantile(method=\'rqss\', lambda=3)')


## ----error=T, eval=F-----------------------------------------------------
## f <- ggplot(mpg, aes(class, hwy))
## f + geom_col()
## f + geom_boxplot(alpha=0.5)
## f + geom_dotplot(binaxis = "y", stackdir = "center")
## f + geom_dotplot(binaxis = "y", stackdir = "center", binwidth=0.7)
## f + geom_violin(scale = "area")

## ----error=T, echo=F, fig.height=2.3-------------------------------------
f <- ggplot(mpg, aes(class, hwy))
f + geom_col() + labs(subtitle='+ geom_col()')
f + geom_boxplot(alpha=0.5) + labs(subtitle='+ geom_boxplot(alpha=0.5)')
f + geom_dotplot(binaxis = "y", stackdir = "center", binwidth=0.7) + labs(subtitle='+ geom_dotplot(binaxis = "y",\nstackdir = "center", binwidth=0.7)')
f + geom_violin(scale = "area") + labs(subtitle='+ geom_violin(scale = "area")
')
# 공란을 채우기 위해 fig.height= 2.78 -> 2.5 -> 2.3


## ---- eval=F, tidy=FALSE-------------------------------------------------
## f <- ggplot(mpg, aes(class, hwy)) + geom_boxplot(alpha=0.5)
## f + geom_dotplot(binaxis="y", stackdir="center", binwidth=1, alpha=0.5)
## f + geom_jitter(alpha=0.5, width=0.1, height=0.1)

## ---- echo=F, fig.height=2.5---------------------------------------------
f <- ggplot(mpg, aes(class, hwy))
f + geom_boxplot(alpha=0.5) + 
  geom_dotplot(binaxis = "y", stackdir = "center", binwidth=1, alpha=0.5) + 
  labs(subtitle='+ geom_boxplot(alpha=0.5) + 
geom_dotplot(binaxis = "y", stackdir = "center", 
binwidth=1, alpha=0.5)')
f + geom_jitter(alpha=0.5, width=0.1, height=0.1) + geom_boxplot(alpha=0.5) + labs(subtitle='+ geom_jitter(alpha=0.5,width=0.1,height=0.1)+
geom_boxplot(alpha=0.5)
')


## ----warning=FALSE, eval=F-----------------------------------------------
## g <- ggplot(diamonds, aes(cut, color))
## g + geom_count()
## g + geom_jitter()

## ----warning=FALSE, echo=F-----------------------------------------------
g <- ggplot(diamonds, aes(cut, color))
g + geom_count() + labs(title= '+ geom_count()')
g + geom_jitter() + labs(title= '+ geom_jitter()')


## ----warning=FALSE, eval=F-----------------------------------------------
## g <- ggplot(diamonds, aes(cut, color))
## g + geom_jitter(alpha=0.02)
## g + geom_jitter(shape='.')

## ----warning=FALSE, echo=F-----------------------------------------------
g <- ggplot(diamonds, aes(cut, color))
#g + geom_jitter(alpha=0.1) + labs(title='+ geom_jitter(alpha=0.1)')
g + geom_jitter(alpha=0.02) + labs(title='+ geom_jitter(alpha=0.02)')
g + geom_jitter(shape='.') + labs(title='+ geom_jitter(shape=\'.\')')


## ---- eval=F-------------------------------------------------------------
## h <- ggplot(diamonds, aes(carat, price))
## h + geom_bin2d(binwidth = c(0.25, 500))
## h + geom_density2d()
## h + geom_hex()
## h + geom_point(alpha=0.2) +
##   stat_ellipse(level=0.95, col="red") +
##   stat_ellipse(level=0.01, col="red", size=3)

## ---- error=F, echo=F----------------------------------------------------
h <- ggplot(diamonds, aes(carat, price)) 
h + geom_bin2d(binwidth = c(0.25, 500)) + labs(title='+ geom_bin2d(binwidth = c(0.25, 500))')
h + geom_density2d() + labs(title='+ geom_density2d()')
h + geom_hex() + labs(title='+ geom_hex()')
h + geom_point(alpha=0.2) + 
  stat_ellipse(level=0.95, col="red") + 
  stat_ellipse(level=0.01, col="red", size=3) + labs(title='+ geom_point(alpha=0.2) + 
stat_ellipse(level=0.95, col="red") + 
stat_ellipse(level=0.01, col="red", size=3)')


## ---- error=F, eval=F----------------------------------------------------
## ggplot(diamonds, aes(carat, color)) + geom_bin2d()
## ggplot(diamonds, aes(cut, color)) + geom_bin2d()

## ---- error=F, echo=F----------------------------------------------------
h2 <- ggplot(diamonds, aes(carat, color))
h2 + geom_bin2d() + labs(title='+ geom_bin2d()')
#h2 + geom_density2d() + labs(title='+ geom_density2d()')
#h2 + geom_hex(bins=c(6, 7)) + labs(title='+ geom_hex()') 
#h2 + geom_hex(bins=c(6, 6)) + labs(title='+ geom_hex()')
#h2 + geom_hex(binwidth=c(1, 1)) + labs(title='+ geom_hex()') 
h3 <- ggplot(diamonds, aes(cut, color))
h3 + geom_bin2d() + labs(title='+ geom_bin2d()')
#h3 + geom_density2d() + labs(title='+ geom_density2d()')
#h3 + geom_hex() + labs(title='+ geom_hex()')# is this correct?


## ----warning=FALSE, eval=F, tidy=FALSE-----------------------------------
## data <- data.frame(murder = USArrests$Murder,
##                    state = tolower(rownames(USArrests)))
## map <- map_data("state")
## k <- ggplot(data, aes(fill = murder))
## k + geom_map(aes(map_id = state), map = map) +
##   expand_limits(x = map$long, y = map$lat)

## ----warning=FALSE, echo=F-----------------------------------------------
data <- data.frame(murder = USArrests$Murder,
                   state = tolower(rownames(USArrests)))
map <- map_data("state")
k <- ggplot(data, aes(fill = murder))
k + geom_map(aes(map_id = state), map = map) + expand_limits(x = map$long, y = map$lat) + 
labs(subtitle='+ geom_map(aes(map_id = state), map = map) + 
expand_limits(x = map$long, y = map$lat)')


## ----fig.align='center', fig.height=2.5, fig.width=6, results=F, out.width='70%',  echo= F----
lty <- c("solid", "dashed", "dotted", "dotdash", "longdash", "twodash")
linetypes <- data.frame(
  y = seq_along(lty),
  lty = lty
) 
ggplot(linetypes, aes(0, y)) + 
  geom_segment(aes(xend = 5, yend = y, linetype = lty)) + 
  scale_linetype_identity() + 
  geom_text(aes(label = lty), hjust = 0, nudge_y = 0.2) +
  scale_x_continuous(NULL, breaks = NULL) + 
  scale_y_reverse(NULL, breaks = NULL)


## ---- eval=F-------------------------------------------------------------
## ggplot(mpg, aes(x = cyl, y = cty)) + geom_jitter(aes(col=drv)) +
##   geom_hline(yintercept=c(10, 20, 30), linetype='dotted')
## ggplot(mpg, aes(x = cyl, y = cty)) +
##   geom_rect(xmin=-Inf, xmax=Inf, ymin=15, ymax=25, fill='lightgray') +
##   geom_jitter(aes(col=drv))

## ---- echo=F-------------------------------------------------------------
ggplot(mpg, aes(x = cyl, y = cty)) + geom_jitter(aes(col=drv)) + 
  geom_hline(yintercept=c(10, 20, 30), linetype='dotted') + 
  labs(subtitle="+ geom_hline(yintercept=c(10, 20, 30),\n  linetype='dotted')")
ggplot(mpg, aes(x = cyl, y = cty)) + 
  geom_rect(xmin=-Inf, xmax=Inf, ymin=15, ymax=25, fill='lightgray') +
  geom_jitter(aes(col=drv)) +
  labs(subtitle="+ geom_rect(xmin=-Inf, xmax=Inf, 
  ymin=15, ymax=25, fill='lightgray')")


## ---- eval=F, tidy=FALSE-------------------------------------------------
## imax <- which.max(mpg$cty)
## ax <- mpg$hwy[imax]; ay <- mpg$cty[imax]
## ggplot(mpg, aes(x=hwy, y=cty)) + geom_jitter(aes(col=drv)) +
##   geom_segment(x=ax-5 , y=ay, xend=ax-0.5, yend=ay,
##                arrow = arrow(length = unit(5, "mm")))

## ---- echo=F-------------------------------------------------------------
imax <- which.max(mpg$cty)
ax <- mpg$hwy[imax]; ay <- mpg$cty[imax]
ggplot(mpg, aes(x = hwy, y = cty)) + geom_jitter(aes(col=drv)) + 
  geom_segment(x=ax-5 , y= ay, xend=ax-0.5 , yend=ay , arrow = arrow(length = unit(5, "mm"))) +
  labs(subtitle='+ geom_segment(x=ax-5 , y=ay, xend=ax-0.5, yend=ay, 
  arrow = arrow(length = unit(5, "mm")))') #+ theme(plot.subtitle = element_text(size=11))


## ---- eval=F-------------------------------------------------------------
## r <- ggplot(mpg, aes(x=fl)) + geom_bar()
## r + coord_cartesian(xlim = c(-1, 5)) # 첫번째 범주 'c'(x=1)
## r + coord_fixed(ratio = 1/10)
## r + coord_flip()
## r + coord_polar(theta = "x", direction=1 )
## r + coord_trans(y = "sqrt")


## ---- echo=F-------------------------------------------------------------
d <- ggplot(mpg, aes(x=fl))
r <- d + geom_bar() 
r + coord_cartesian(xlim = c(-1, 5)) + labs(subtitle='+ coord_cartesian(xlim = c(-1, 5))')
r + coord_fixed(ratio = 1/10) + labs(subtitle='+ coord_fixed(ratio = 1/10)')
r + coord_flip() + labs(subtitle='+ coord_flip()')
r + coord_polar(theta = "x", direction=1 ) + labs(subtitle='+ coord_polar(theta = "x",\ndirection=1)')  
r + coord_trans(y = "sqrt") + labs(subtitle='+ coord_trans(y = "sqrt")')


## ---- collapse=T, eval=F-------------------------------------------------
## r
## r + labs(x='fuel type', y='frequency')

## ---- collapse=T, echo=F-------------------------------------------------
r + labs(subtitle=' ')
r + labs(x='fuel type', y='frequency') + labs(subtitle="+ labs(x='fuel type', y='frequency')")


## ---- collapse=T, eval=F-------------------------------------------------
## (n <- d + geom_bar(aes(fill = fl)))
## n + scale_fill_manual(
##   values = c("skyblue", "royalblue", "blue", "navy"),
##   limits = c("d", "e", "p", "r"), breaks =c("d", "e", "p", "r"),
##   name = "fuel", labels = c("D", "E", "P", "R"))
## n + scale_fill_discrete(
##   #palette = "Blues",
##   breaks =c("d", "p"),
##   labels = c("D", "E")) +
##   guides(fill='none')
## t <- ggplot(mpg, aes(cty, hwy)) + geom_point()
## t + scale_x_continuous(
##   breaks=seq(10,40,10),
##   labels=c('ten', 'twenty', 'thirty', 'forty'))

## ---- collapse=T, echo=F-------------------------------------------------
(n <- d + geom_bar(aes(fill = fl)) + labs(subtitle=' '))
n + scale_fill_manual( 
  values = c("skyblue", "royalblue", "blue", "navy"), 
  limits = c("d", "e", "p", "r"), breaks =c("d", "e", "p", "r"), 
  name = "fuel", labels = c("D", "E", "P", "R")) + labs(subtitle='+ scale_fill_manual(values=c("skyblue","royalblue"')
n + scale_fill_discrete( 
  #palette = "Blues",
  breaks =c("d", "p"), 
  labels = c("D", "E")) +
  guides(fill='none') + labs(subtitle='+ scale_fill_discrete(breaks=c("d", "p"), labels=c("D","E"))')
t <- ggplot(mpg, aes(cty, hwy)) + geom_point() 
t + scale_x_continuous(
  breaks=seq(10,40,10), 
  labels=c('ten', 'twenty', 'thirty', 'forty')) + labs(subtitle='+ scale_x_continuous(break=seq(10,40,10))')


## ---- collapse = T, eval=F, tidy=FALSE-----------------------------------
## t <- ggplot(mpg, aes(displ, hwy)) + geom_point() + geom_smooth(method='lm')
## t

## ---- echo = F-----------------------------------------------------------
t <- ggplot(mpg, aes(displ, hwy)) + geom_point() + geom_smooth(method='lm')
t + labs(subtitle="+ geom_point() +\ngeom_smooth(method='lm')")


## ---- eval=F-------------------------------------------------------------
## t + coord_cartesian(xlim = c(1.5, 2), ylim = c(20, 50))

## ---- echo=F-------------------------------------------------------------
t +
  coord_cartesian(xlim = c(1.5, 2), ylim = c(20, 50)) + 
  labs(subtitle='+ coord_cartesian(xlim=c(1.5,2),\nylim=c(20,50))')


## ---- eval=F, tidy=FALSE-------------------------------------------------
## t + xlim(1.5, 2) + ylim(20, 50)
## t + scale_x_continuous(limits = c(1.5, 2)) +
##   scale_y_continuous(limits = c(20, 50))

## ----echo=F, message=FALSE, warning=FALSE--------------------------------
t + xlim(1.5, 2) + ylim(20, 50) + 
  labs(title='+ xlim(1.5, 2) + ylim(20, 50)\n ')
t + scale_x_continuous(limits = c(1.5, 2)) + scale_y_continuous(limits = c(20, 50)) +
  labs(subtitle='+ scale_x_continuous(limits=c(1.5,2)) +
scale_y_continuous(limits=c(20,50))')


## ---- eval=F-------------------------------------------------------------
## t <- ggplot(mpg, aes(x = displ, y=cty,  color=cyl)) + geom_point()
## t + scale_x_continuous(name='city miles per gallon')
## t + labs(color='number of cylinders')
## t + theme(legend.position='bottom') # top, bottom, left, right
## t + guides(color='none')
## t + guides(color='colorbar')
## t + guides(color='legend')
## t + scale_color_continuous(labels = c('two', 'three', 'four', 'five', 'six'))


## ---- echo=F-------------------------------------------------------------
t <- ggplot(mpg, aes(x = displ, y=cty,  color=cyl)) + geom_point() 
t + scale_x_continuous(name='city miles per gallon')+ labs(subtitle="+ scale_x_continuous(name=\n'city miles per gallon')")
t + labs(color='number of cylinders')+ labs(subtitle="+ labs(color='number of cylinders')\n ")
t + theme(legend.position='bottom') + labs(subtitle="+ theme(legend.position='bottom') ")
# top, bottom, left, right
t + guides(color='none')+ labs(subtitle="+ guides(color='none')")

t + guides(color='colorbar')+ labs(subtitle="+ guides(color='colorbar')")

t + guides(color='legend')+ labs(subtitle="+ guides(color='legend')")
t + scale_color_continuous(labels = c('two', 'three', 'four', 'five', 'six'))+ labs(subtitle="+ scale_color_continuous(labels=\nc('two', 'three', 'four', 'five', 'six'))")



## ---- eval=F, tidy=FALSE-------------------------------------------------
## t <- ggplot(mpg, aes(cty, hwy, color=cyl)) + geom_point()
## t + labs(title='1. Fuel economy data')
## t + labs(title='2. Fuel Economy Data',
##          subtitle='from 1999 and 2008
## for 38 popular models of car')
## # 줄을 바꾸기 위해 '\n'을 사용할 수도 있다.
## t + labs(title='3. Fuel Economy Data',
##          subtitle='from 1999 and 2008\nfor 38 popular models of car',
##          caption='Fig. x. This dataset contains a subset of
## the fuel economy data that the EPA makes available
## on http://fueleconomy.gov.')
## 

## ---- echo=F-------------------------------------------------------------
t <- ggplot(mpg, aes(cty, hwy, color=cyl)) + geom_point() 
t + labs(title='1. Fuel economy data')
t + labs(title='2. Fuel Economy Data',
         subtitle='from 1999 and 2008
for 38 popular models of car')
t + labs(title='3. Fuel Economy Data',
         subtitle='from 1999 and 2008
for 38 popular models of car',
         caption='Fig. x. This dataset contains a subset of
the fuel economy data that the EPA makes available
on http://fueleconomy.gov.')
# 줄을 바꾸려면 '\n'을 사용한다. 


## ---- eval=F, tidy=FALSE-------------------------------------------------
## t <- ggplot(mpg, aes(cty, hwy, color=cyl)) + geom_point()
## t2 <- t + labs(subtitle='from 1999 and 2008
## for 38 popular models of car',
##          caption='Fig. x. This dataset contains a subset of
## the fuel economy data that the EPA makes available
## on http://fueleconomy.gov.')
## t2 + theme_bw()
## t2 + theme_gray()
## t2 + theme_dark()
## t2 + theme_classic()
## t2 + theme_light()
## t2 + theme_linedraw()
## t2 + theme_minimal()
## t2 + theme_void()


## ---- echo=F-------------------------------------------------------------
t <- ggplot(mpg, aes(cty, hwy, color=cyl)) + geom_point() 
t2 <- t + labs(title='3. Fuel Economy Data',
         subtitle='from 1999 and 2008
for 38 popular models of car',
         caption='Fig. x. This dataset contains a subset of
the fuel economy data that the EPA makes available
on http://fueleconomy.gov.')
t2 + theme_bw() + labs(title = '+ theme_bw()')
t2 + theme_gray() + labs(title = '+ theme_gray()')
t2 + theme_dark() + labs(title = '+ theme_dark()')
t2 + theme_classic() + labs(title = '+ theme_classic()')
t2 + theme_light() + labs(title = '+ theme_light()')
t2 + theme_linedraw() + labs(title = '+ theme_linedraw()')
t2 + theme_minimal() + labs(title = '+ theme_minimal()')
t2 + theme_void()  + labs(title = '+ theme_void()')


## ---- eval=F-------------------------------------------------------------
## t2 <- ggplot(mpg, aes(cty, hwy, color=cyl)) + geom_point() +
##   labs(caption='Fig. x. This dataset contains a subset of
## the fuel economy data that the EPA makes available
## on http://fueleconomy.gov.')
## t2 + theme(plot.caption = element_text(hjust = 0))
## t2 + theme(plot.caption = element_text(hjust = 0.5))
## t2 + theme(plot.caption = element_text(hjust = 1))
## t2 + theme(plot.caption = element_text(angle = 0))
## t2 + theme(plot.caption = element_text(angle = 10))
## t2 + theme(plot.caption = element_text(lineheight=.8, face='bold'))
## t2 + theme(axis.text.x = element_text(angle = 45))
## t2 + theme(axis.text.x = element_text(angle = 90))


## ---- echo=F-------------------------------------------------------------
t2 <- ggplot(mpg, aes(cty, hwy, color=cyl)) + geom_point() + 
  labs(caption='Fig. x. This dataset contains a subset of
the fuel economy data that the EPA makes available
on http://fueleconomy.gov.')
t2 + theme(plot.caption = element_text(hjust = 0))+ labs(subtitle="+ theme(plot.caption = element_text(hjust = 0))")
t2 + theme(plot.caption = element_text(hjust = 0.5))+ labs(subtitle="+ theme(plot.caption = element_text(hjust = 0.5))")
t2 + theme(plot.caption = element_text(hjust = 1)) + labs(subtitle = "theme(plot.caption = element_text(hjust = 1))")
t2 + theme(plot.caption = element_text(angle = 0))+ labs(subtitle="+ theme(plot.caption = element_text(angle = 0))")
t2 + theme(plot.caption = element_text(angle = 10))+ labs(subtitle="+ theme(plot.caption = element_text(angle = 10))")
t2 + theme(plot.caption = element_text(lineheight=.8, face='bold'))+ labs(subtitle="+ theme(plot.caption = element_text(lineheight=.8, face='bold'))")
t2 + theme(axis.text.x = element_text(angle = 45))+ labs(subtitle="+ theme(axis.text.x = element_text(angle = 45))")
t2 + theme(axis.text.x = element_text(angle = 90))+ labs(subtitle="+ theme(axis.text.x = element_text(angle = 90))")


## ---- out.width="90%", fig.width=7.4, fig.height=5.56--------------------
p1 <- ggplot(mtcars, aes(x=mpg, y=wt, col=factor(vs))) + geom_point()
p2 <- ggplot(mtcars, aes(x=factor(vs), fill=factor(am))) + geom_bar()
p3 <- ggplot(mtcars, aes(x=wt, y=qsec, col=factor(gear))) + geom_line()
p4 <- ggplot(mtcars, aes(x=disp, y=drat)) + geom_point(col='red') + theme_minimal()
gridExtra::grid.arrange(p1, p2, p3, p4, ncol=2)

## ---- out.width="90%", fig.width=7.4, fig.height=2.78--------------------
cowplot::plot_grid(p1, p2, labels = c("A", "B"), align = "h")


## ------------------------------------------------------------------------
p <-
  mtcars %>% 
  transmute(cyl=factor(cyl), gear=factor(gear)) %>%
  ggplot(aes(x=cyl, fill=gear)) + geom_bar()

mtcars %>% 
  transmute(cyl=factor(cyl), hp=hp, am = factor(am)) %>%
  ggplot(aes(x=cyl, y = hp, fill=am)) + geom_boxplot()

ggsave(filename = 'picRecent.png') 
ggsave(filename = 'picp.jpg', plot=p)


## ---- include=FALSE------------------------------------------------------
knitr::opts_chunk$set(tidy.opts=list(width.cutoff=72, indent = 2), tidy = FALSE)
options(max.print=o[[1]])

