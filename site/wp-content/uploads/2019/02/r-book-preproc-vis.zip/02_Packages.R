## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
###tags=
###category=


## ----include=FALSE-------------------------------------------------------
if ('package:psych' %in% search()) {
  detach('package:psych')
}


## ----eval=FALSE----------------------------------------------------------
## options(repos='http://healthstat.snu.ac.kr/CRAN/')
## install.packages("psych")


## ------------------------------------------------------------------------
maintainer("psych")


## ---- eval=FALSE---------------------------------------------------------
## citation("psych")


## ----error=T-------------------------------------------------------------
library(psych)
describe(mtcars)
search()
detach("package:psych")
describe(mtcars)
search()


## ---- eval=F-------------------------------------------------------------
## options(repos='http://healthstat.snu.ac.kr/CRAN/')
## installed.packages()
## update.packages("psych")


## ------------------------------------------------------------------------
library(psych)
library(car) # car : Companion to Applied Regression
psych::logit(60)
car::logit(60)
logit(60)

