## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
knitr::opts_chunk$set(out.width='60%')
# 3.7x2.78 for 55%  = 4.04x30.3 for 60%
knitr::opts_chunk$set(fig.width=4.04)  
knitr::opts_chunk$set(fig.height=3.53) 
# ggplot2 = 2.78

knitr::opts_chunk$set(fig.show='hold')
knitr::opts_chunk$set(fig.align='default')
library(dplyr)
library(ggplot2)


## ------------------------------------------------------------------------
library(lattice)
data('BankWages', package='AER')
data(mtcars)
hist(BankWages$education) # 연속형 변수
plot( ~ gender, data=BankWages) # 이산형 변수


## ------------------------------------------------------------------------
# 데이터 준비 : 범주 비율이 차이를 두기 위해서
Bank1 <- BankWages %>% slice(1:200) %>% filter(gender == 'male')
Bank2 <- BankWages %>% slice(-(1:200))
Bank <- rbind(Bank1, Bank2)

# 이변수 그림 : x=이산형, y=이산형
plot(job ~ gender, data=Bank)
# 이변수 그림 : x=이산형, y=연속형
plot(education ~ gender, data=Bank)
# 이변수 그림 : x=연속형, y=연속형
plot(qsec ~ hp, mtcars)


## ------------------------------------------------------------------------
histogram( ~ job | gender, BankWages)
histogram( ~ job | gender * minority, BankWages)


## ------------------------------------------------------------------------
# 조건부 이변수 그림 : x=범주형, y=연속형
xyplot(education ~ job | gender, BankWages)
xyplot(education ~ job | gender, BankWages, jitter.x=TRUE)


## ------------------------------------------------------------------------
# 조건부 이변수 그림 : x=연속형, y=연속형
xyplot(qsec ~ hp | mpg, mtcars)
mpgequal <- equal.count(mtcars$mpg, number=3, overlap=0)
xyplot(qsec ~ hp | mpgequal, mtcars)

mpgequal <- equal.count(mtcars$mpg, number=5, overlap=0)
xyplot(qsec ~ hp | mpgequal, mtcars)

mpgequal <- equal.count(mtcars$mpg, number=5, overlap=0.2)
xyplot(qsec ~ hp | mpgequal, mtcars)

