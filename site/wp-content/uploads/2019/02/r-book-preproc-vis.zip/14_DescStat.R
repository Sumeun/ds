## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ------------------------------------------------------------------------
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}


## ---- results='hold', tidy=FALSE-----------------------------------------
set.seed(0); x <- rnorm(10); x
mean(x)
median(x)
Mode(x) # table을 통해 빈도수를 확인할 수 있다. 
mean(x, trim = 0.2)


## ---- tidy=FALSE, results='hold'-----------------------------------------
max(x)-min(x)
IQR(x)
var(x)
sd(x)


## ---- eval=F, tidy=F-----------------------------------------------------
## gini = function(x, ...) { #useNA = 'always', 'no', 'ifany'
##   sum(1-prop.table(table(x, ...))^2)
## }


## ----message=FALSE, warning=FALSE, tidy=FALSE, collapse=TRUE-------------
data(mpg, package='ggplot2'); require(dplyr)
mpg$drv <- ordered(mpg$drv, levels=c("f", "r", "4"))
mpg$fl <- factor(mpg$fl)
mpg2 <- mpg %>% select(class, drv, fl, hwy)
summary(mpg2)


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## prettyR::freq(mpg2)
## 
## ## Frequencies for drv
## ##         f    4    r   NA
## ##       106  103   25    0
## ## %    45.3   44 10.7    0
## ## %!NA 45.3   44 10.7
## ##
## ## Frequencies for hwy
## ##        26   17   29   25   27   19   24   20   15   18   16   22   ...
## ##        32   31   22   15   14   13   13   11   10   10    7    7   ...
## ## %    13.7 13.2  9.4  6.4    6  5.6  5.6  4.7  4.3  4.3    3    3   ...
## ## %!NA 13.7 13.2  9.4  6.4    6  5.6  5.6  4.7  4.3  4.3    3    3   ...


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## psych::describe(mpg2)
## ##
## ##        vars   n  mean   sd median trimmed  mad min  max range  skew ...
## ## class*    1 234   NaN   NA     NA     NaN   NA Inf -Inf  -Inf    NA ...
## ## drv*      2 234  1.99 0.95      2    1.98 1.48   1    3     2  0.03 ...
## ## fl*       3 234  4.63 0.70      5    4.77 0.00   1    5     4 -2.25 ...
## ## hwy       4 234 23.44 5.95     24   23.23 7.41  12   44    32  0.36 ...


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## Hmisc::describe(mpg2)
## 
## ## ---------------------------------------------------------------------
## ## drv
## ##    n  missing distinct
## ##  234        0        3
## ##
## ## Value          4     f     r
## ## Frequency    103   106    25
## ## Proportion 0.440 0.453 0.107
## ## ---------------------------------------------------------------------
## ## hwy
## ##    n  missing distinct  Info  Mean   Gmd  .05  .10  .25  .50  .75 ...
## ##  234        0       27 0.993 23.44 6.668 15.0 16.3 18.0 24.0 27.0 ...
## ##
## ## lowest : 12 14 15 16 17, highest: 35 36 37 41 44
## ## ---------------------------------------------------------------------


## ---- collapse=TRUE, eval=FALSE, tidy=FALSE------------------------------
## pastecs::stat.desc(mpg2)
## 
## ##          class drv fl          hwy
## ## nbr.val     NA  NA NA  234.0000000
## ## nbr.null    NA  NA NA    0.0000000
## ## nbr.na      NA  NA NA    0.0000000
## ## min         NA  NA NA   12.0000000

