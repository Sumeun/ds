## ---- include=FALSE------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
backtick = '`'


## ---- include=F----------------------------------------------------------
linespreadcode=1.1
linespreadtable=1.0
linespread = 1.25


## ---- results='hold'-----------------------------------------------------
# combine, concatenate
c(1,3,2,4); 
c(pi, 1e-3, sin(3)); 
c("John","Mary")


## ------------------------------------------------------------------------
# with names
person = c(name = "John", likes = "Mary", loves = "Suzy")


## ---- results='hold'-----------------------------------------------------
# repeat
rep(1, 10)
rep("ABC", 10)
rep(c("A","B","C"), 3)


## ---- results='hold'-----------------------------------------------------
# sequence
seq(from=1, to=10) # 1부터 10까지
seq(from=1, to=10, by=2) # 1부터 10까지 2 간격으로 
seq(from=1, to=10, length.out=3) # 1부터 10까지 총길이 3으로
rep(seq(1,4),each=3) # 1부터 4까지 각각 3번 반복
seq(1,10)
1:10


## ---- tidy=FALSE---------------------------------------------------------
vInteger <- as.integer(1:35)
vReal1 <- rnorm(10); vReal2 <- c(1.2475842, 1.43, 10240333211)
vCharacter <- c("안녕?\n또 보다니!", "Hi,\tWait a moment", 
                "오랜만이야?\t!", "Long time no see!", "...")
vFactor <- factor(c('hi', 'mid', 'low', 'low', 'mid'), 
                  levels=c('hi', 'mid', 'low'))
vDate <- as.Date(c("2017-06-14", "2019-03-01", "2019-01-01"))
vPOSIXct <- as.POSIXct(c("2017-06-14 15:00:00", "2019-03-01 12:14:15"))


## ------------------------------------------------------------------------
print(vInteger)


## ---- results='hold'-----------------------------------------------------
print(vReal1)
print(vReal2)


## ---- results='hold'-----------------------------------------------------
print(vCharacter)
cat(vCharacter); 


## ------------------------------------------------------------------------
print(vFactor)


## ------------------------------------------------------------------------
print(vDate); print(vPOSIXct)


## ---- fig.align='center', out.width='50%'--------------------------------
vec <- sample(1:100,10000,replace=T)
#print(vec)
head(vec)
tail(vec)
summary(vec)
psych::describe(vec)


## ---- eval=FALSE---------------------------------------------------------
## vecCut <- cut(vec,breaks=seq(-0.5, 100.5, 10))
## table(vecCut)
## hist(vec)
## hist(vec, breaks=seq(-0.5, 100.5, 1))


## ---- error=T, tidy=FALSE------------------------------------------------
vec <- sample(c("John","Mary","Tom"), 100, replace=T)

head(vec)
tail(vec)
summary(vec) # 에러는 나지 않지만 특별한 정보를 주지 않는다
#psych::describe(vec) # 문자열 벡터에는 사용불가
table(vec)
#hist(vec) # 문자열 또는 팩터형 벡터에는 사용 불가


## ---- results='hold', tidy=FALSE-----------------------------------------
x = 1:5; y = 2:6

x + y
x - y
x * y
x / 3


## ---- results='hold', tidy=FALSE-----------------------------------------
x = 1:5; y=2:3

x + y  # 1:5 + c(2:3, 2:3, 2)
x - y


## ---- results='hold', tidy=FALSE-----------------------------------------
x = 1:5; y = 2

x + y  # 1:5 + c(2, 2, 2, 2, 2)
x - y


## ------------------------------------------------------------------------
c(1,2,3,c(4,5),c(6,7,8))


## ------------------------------------------------------------------------
length(x)


## ---- tidy=FALSE---------------------------------------------------------
v1 <- c(1,3,2); v2 <-c(3,3,1)

v1 < v2


## ---- results='hold'-----------------------------------------------------
all(v1 < v2)
any(v1 < v2)


## ---- results='hold'-----------------------------------------------------
v1 = c("I", "You", "He")
v2 = c("go", "come", "climbs")

nchar(v1)
paste(v1, v2)
substring(v2, 2, 2)
substring(v2, c(1,2,3), c(2,5,5))


## ---- results='hold', tidy=FALSE-----------------------------------------
vec <- sample(100,10000,replace=T)

mean(vec)
sum(vec)
sd(vec)


## ---- results='hold', tidy=FALSE-----------------------------------------
xa = c(1,3,2); xb = c(2,3,2); xc = c(1,1,2)
xa == xb & xb == xc
xa == xb && xb == xc


## ---- results='hold', tidy=FALSE-----------------------------------------
primes <- c(2,3,5,7,11,13,17,19,7,13)
numbersILike <- c(3,7,14,3)

union(primes, numbersILike)
intersect(primes, numbersILike)
setdiff(numbersILike , primes)


## ---- results='hold', tidy=FALSE-----------------------------------------
numbersILike2 <- c(3, 7, 14)

setequal(numbersILike , numbersILike2)


## ---- results='hold'-----------------------------------------------------
is.element(17, primes)
is.element(18, primes)
17 %in% primes
18 %in% primes


## ------------------------------------------------------------------------
v = c(180, 169, 172, 154, 190, 155, 201)


## ------------------------------------------------------------------------
v[5]


## ------------------------------------------------------------------------
v[c(2,3,5)]


## ---- results='hold'-----------------------------------------------------
vec = 1:10; vec[c(2,3,5,7)]
index = c(2,3,5,7); vec[index]


## ---- results='hold'-----------------------------------------------------
vec[-1] # 첫 번째 원소 제외
vec[-1:-2] # 첫 번째와 두 번째 원소 제외
vec[index][-1] # index(2,3,5,7)번째 원소 중에서 첫 번째 원소 제외


## ---- tidy=FALSE, results='hold'-----------------------------------------
vHeight = c(Park = 180, Jung = 169, Hyori = 172, 
            DJDoc = 154, Queen = 190, Dooli = 155, MJ = 201)

vHeight['DJDoc']
vHeight[c('Park', 'Hyori')]


## ---- results='hold'-----------------------------------------------------
vHeight[c(T, F, T, F, T, F, T)] # 벡터 vHeight의 1번째, 3번째, 5번째, 7번째 원소
vHeight[vHeight > 170] # vHeight의 원소 중 170보다 큰 원소


## ---- collapse=TRUE, tidy=FALSE, eval=F----------------------------------
## vec = sample(5, 10, replace=T)
## vec
## ## [1] 2 2 3 5 1 4 5 1 4 1
## biggerThan3 = vec > 3; vec[biggerThan3]
## vec[vec > 3]
## vec[c(T,F)]
## # c(T, F)는 벡터 vec의 길이만큼 늘어난다(재활용). 따라서 홀수 순번의 원소를 선택한다.

## ---- echo=FALSE---------------------------------------------------------
vec = c(2, 2, 3, 5, 1, 4, 5, 1, 4, 1)
#vec
## [1] 2 2 3 5 1 5 5 1 5 1
biggerThan3 = vec > 3; vec[biggerThan3]
vec[vec > 3]
vec[c(T,F)] 


## ---- results='hold', tidy=FALSE-----------------------------------------
vec = c(1, 5, 6, 4, 2)

sort(vec)
order(vec)
vec[order(vec)]


## ----eval=FALSE, include=FALSE-------------------------------------------
## #### 그밖의 참고 자료
## 
## #* <http://adv-r.had.co.nz/Subsetting.html>


## ------------------------------------------------------------------------
vec = c(7,2,3,4,5,6,8,6,9,10,11,12,11,8,5)
matrix(vec, nrow=3, ncol=5)


## ------------------------------------------------------------------------
matrix(vec, nrow=3, ncol=5, byrow=TRUE)


## ------------------------------------------------------------------------
matrix(vec, 3, 5)


## ------------------------------------------------------------------------
matrix(vec, nrow=7)


## ------------------------------------------------------------------------
vec <- 1:(3*5*4)
arr <- array(vec, c(3,5,4))


## ---- tidy=FALSE---------------------------------------------------------
list(c(1,2,3), 
     matrix(1:9, 3,3),
     list(c(4,5,6), matrix(11:19,3,3)))


## ---- include=F----------------------------------------------------------
linespread=1.3


## ---- include=F----------------------------------------------------------
linespread=1.3


## ---- results='hold'-----------------------------------------------------
mtcars[3,7]
mtcars[c(F,F,T,rep(F, 29)), c(rep(F,6), T, rep(F,6))]
mtcars["Mazda RX4", "disp"]
mtcars[3:4,c(rep(F,6), T, T, rep(F,5))]
mtcars[c("Mazda RX4", "Mazda RX4 Wag"), 7:8]


## ---- include=FALSE------------------------------------------------------
ooe <- options("max.print")
options(max.print = 9999)

## ------------------------------------------------------------------------
# with : 계산만 하고 싶을 때
with(mtcars, mpg/cyl + hp*drat) 
# within : 만약 새로운 열로 저장하고 싶을 때
dat <- within(mtcars, x <- mpg/cyl + hp*drat)
head(dat, n=3)

## ---- include=FALSE------------------------------------------------------
options(max.print = ooe[[1]])


## ------------------------------------------------------------------------
mtcars[1,]
unlist(mtcars[1,])


## ---- tidy=FALSE---------------------------------------------------------
dat = data.frame(name=c('Kim', 'Lee'), 
                 age=c(23,41), 
                 height=c(180, 165), stringsAsFactors=FALSE); dat
dat[2,1] <- 'Park'; dat
dat$age <- c(24,40); dat


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## dat[1,] <- c("Lee", 30, 170); dat
## dat[1,] <- list("Lee", 30, 170); dat


## ---- include=F----------------------------------------------------------
linespread=1.4


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- include=F----------------------------------------------------------
c(210, 297) # original size 
c(182,256) # current size
-(c(210, 297)-c(182,256))/2 + c(-3.5,0) # -17.5, -20.5 -> 1cm 위로 -17.5, -10.5


## ------------------------------------------------------------------------
d3 <- d2 <- d1 <- 1:10
dat <- expand.grid(d1, d2, d3)
colnames(dat) <- c("d1", "d2", "d3")
dat$x <- rnorm(nrow(dat))

object.size(dat)
a <- array(dat$x, dim = c(length(d1), length(d2), length(d3)))

object.size(a)


## ------------------------------------------------------------------------
dat[dat$d1==5 & dat$d2==10 & dat$d3==4, "x"]
a[5, 10, 4]


## ------------------------------------------------------------------------
a2.array <-  structure(rnorm(3*5*3*3), .Dim = c(3L, 5L, 3L, 3L))


## ------------------------------------------------------------------------
dim(a2.array) # dim은 dimension(차원)의 약자이다.
dimnames(a2.array)


## ---- tidy=FALSE---------------------------------------------------------
#01
dimnames(a2.array) = list(c(0, 0.3, 0.6), 
                          c(100, 200, 300, 500, 1000), 
                          c(5, 10, 20),
                          c("norm","unif","skew"))
names(dimnames(a2.array))=c("a2","n.subj","n.item","thDist")


## ------------------------------------------------------------------------
#02
dimnames(a2.array) = list(a2=c(0, 0.3, 0.6), 
                          n.subj=c(100, 200, 300, 500, 1000), 
                          n.item=c(5, 10, 20), 
                          thDist=c("norm","unif","skew"))


## ------------------------------------------------------------------------
dimnames(a2.array)


## ------------------------------------------------------------------------
a1.array <- a2.array+rnorm(prod(dim(a2.array)), 0, 0.01)
a3.array <- a2.array+rnorm(prod(dim(a2.array)), 0, 0.01)
a4.array <- a2.array+rnorm(prod(dim(a2.array)), 0, 0.01)


## ------------------------------------------------------------------------
library(abind) # install.packages("abind")
a.array <- abind(a1.array, a2.array, a3.array, a4.array, along=0) 


## ------------------------------------------------------------------------
a.array_ <- abind(a1.array, a2.array, a3.array, a4.array)
a.array_ <- abind(a1.array, a2.array, a3.array, a4.array, along=5)


## ---- echo=FALSE, include=FALSE------------------------------------------
dimnames(a.array) = 
  append(list(param=c("a1","a2","a3","a4")), 
         dimnames(a2.array))
names(dimnames(a.array))[2] = "true"
dimnames(a.array)

## ---- eval=FALSE,  echo=TRUE, tidy=FALSE---------------------------------
## dimnames(a.array) =
##   append(list(param=c("a1","a2","a3","a4")),
##          dimnames(a2.array))
## names(dimnames(a.array))[2] = "true"
## dimnames(a.array)


## ------------------------------------------------------------------------
B <- apply(a.array, c(2,3,4), mean)


## ---- echo=F-------------------------------------------------------------
B <- apply(a.array, c(2,3,4), mean)
C <- aperm(B, c(2,3,1))


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## round(ftable(C, row.vars=c(1,2)), 02)


## ---- include=F----------------------------------------------------------
linespreadcode=1.1
linespreadtable=1.0
linespread = 1.2

