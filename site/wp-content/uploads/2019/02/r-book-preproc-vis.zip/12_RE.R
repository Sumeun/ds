## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
load('linespread.RData')
load('linespreadtable.RData')
#linespread = 1.2


## ---- results='hold', tidy=FALSE-----------------------------------------
str <- c("인터스텔라의 장면 62.",
         "부모가 되면[5-7],",
         "아이들-내 아이는 10살이다.-이 안심하고 자랄 수 있게 하고 싶다.",
         "2027년 2월 3일.")
## 숫자를 나타내는 문자 "1", "2", "3"
grepl("1", str, fixed=TRUE) | grepl("2", str, fixed=TRUE) | 
  grepl("3", str, fixed=TRUE) 
## 숫자 "1", "2", "3"을 나타내는 정규표현식 "[1-3]"
grepl(pattern = "[1-3]", str)


## ---- tidy=FALSE, results='hold'-----------------------------------------
x <- c('I dare to love you', 'I dare to love you!', 
       'Oh1', 'Dear, my love.2', '!!?!')
grep('[[:punct:]]', x) # 문장부호가 포함되었는가?
grep('[[:punct:]1]', x) # 문장부호 또는 1이 포함되었는가?
grep('[1[:punct:]]', x) # 1 또는 문장부호가 포함되었는가?
grep('[^[:punct:]]', x) # 문장부호가 아닌 문자가 포함되었는가?


## ---- tidy=FALSE, results='hold'-----------------------------------------
x <- c('Idaretoloveyou', 'I dare to love you!', 
       'Oh1', 'Dear, my love.1', '!!?!')
grep('\\w', x)
grep('\\W', x)

## ---- tidy=FALSE, results='hold'-----------------------------------------
grep('\\s', x)
grep('\\S', x) 


## ---- results='hold'-----------------------------------------------------
x <- c('\a', '\b')
grep('\a', x)
grep('\\a', x)


## ---- error=TRUE, tidy=FALSE---------------------------------------------
x <- c('\x1b', '\x1c')
grep('\\e', x)


## ---- error=TRUE, tidy=FALSE---------------------------------------------
grep('\e', x)


## ---- results='hold', tidy=FALSE-----------------------------------------
x <- c('\u00b1', '\u00b2')
grep('\u00b1', x)
grep('\\x{00b1}', x)
grep('[\u00b1]', x)
grep('[\\x{00b1}]', x) # grep("[\\x{000b1}]", "{")의 결과를 예측해보자.


## ---- results='hold'-----------------------------------------------------
x <- "Test On. <h> Hi! </h> Test Off."
grepl("<.+>", x)
grepl("<.+?>", x)


## ---- results='hold'-----------------------------------------------------
regmatches(x, regexpr("<.+>", x)) 
# stringr::str_extract(x, "<.+>")을 사용하면 편하다.
regmatches(x, regexpr("<.+?>", x))


## ---- results='hold'-----------------------------------------------------
x <- c("hook", "I have a hook", "He shook me")

grepl("hook", x)
grepl("^hook", x)
grepl("hook$", x)


## ---- results='hold'-----------------------------------------------------
grepl("\\bhook", x)
grepl("\\Bhook", x)


## ---- results='hold'-----------------------------------------------------
x <- c("abcxabc", "abxab", "abcxab", "abxabc")

grepl("[abc]{2,3}x[abc]{2,3}", x)
grepl("([abc]{2,3})x\\1", x)


## ------------------------------------------------------------------------
x <- c('abba', '2xx2', 'a22z', 'xaxx')
grepl('(\\w)(\\w)\\2\\1', x)


## ---- results='hold'-----------------------------------------------------
x <- c('axxbba', 'axybba', '2yyxx2', 'cxy22c')
grepl('(\\w)(xx|yy)(\\w)\\3\\1', x)
grepl('(\\w)(?:xx|yy)(\\w)\\2\\1', x)


## ------------------------------------------------------------------------
names <- c('김남수', '하이연', '정진성', '김우주',
           '박구수', '성우장', '박의수')
grep('^박.*수$', names)


## ---- tidy=FALSE---------------------------------------------------------
names <- c('김남수', '하이연', '정진성', '김우주',
           '박구수', '성우장', '박의수')
sub(pattern='^([김박])(.*)([주수])$', 
    replacement="\\1\\2수\\\\김\\2\\3", names)


## ---- results='hold'-----------------------------------------------------
grepl("[\\d]", c("3", "d", "\\"))
grepl("[\\d]", c("3", "d", "\\"), perl=TRUE)


## ---- results='hold'-----------------------------------------------------
grepl("(?i)[abc]", c("a", "A", "e", "E"), perl=TRUE)
grepl("(?i)[abc](?-i)[abc]", c("aa", "AA", "ee", "EE"), perl=TRUE)


## ---- results='hold'-----------------------------------------------------
grepl("^I", c("You\nI\nHe", "I\nYou\nHe"))
grepl("(?m)^I", c("You\nI\nHe", "I\nYou\nHe"), perl=TRUE)


## ---- include=FALSE------------------------------------------------------
.w <- options("width")
options(width=72)


## ---- results='hold', error=TRUE, eval=FALSE, tidy=FALSE-----------------
## grepl('\\d+*!*+\\d', c("3+*!*+2", "2!!!2"), perl=TRUE)
## ## Error in grepl("\\d+*!*+\\d", c("3+*!*+2", "2!!!2"), perl = TRUE) :
## ##   invalid regular expression '\d+*!*+\d'
## ## ...
## grepl('\\d\\Q+*!*+\\E\\d', c("3+*!*+2", "2!!!2"), perl=TRUE)
## ## [1] TRUE FALSE


## ---- include=FALSE------------------------------------------------------
options(width=.w$width)


## ------------------------------------------------------------------------
library(stringr)
str <- c("3+*!*+2", "2!!!2")
str %>% str_detect('\\d\\Q+*!*+\\E\\d')


## ---- include=F----------------------------------------------------------
## Originally, rexFunctions.Rmd(2019-02-13)

