## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
###tags=하나,둘,셋,넷
###category=열,둘
load('linespread.RData')
load('linespreadtable.RData')
load('linespreadcode.RData')


## ---- include=F----------------------------------------------------------
linespread=1.3


## ---- include=F----------------------------------------------------------
linespread=1.3


## ------------------------------------------------------------------------
v <- c(172, 172, 170, 170, rnorm(96, 170, 3))
g <- rep(c("Male", "Female"), 50)
c(mean(v[g=="Male"]), mean(v[g=="Female"]))


## ------------------------------------------------------------------------
set.seed(0)
v <- rnorm(1000, 170, 3)
g <- rep(1:100, 10)
c(mean(v[g==1]), mean(v[g==2]), mean(v[g==3]), mean(v[g==4]))


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- include=F----------------------------------------------------------
linespread=1.3


## ---- eval=FALSE---------------------------------------------------------
## g = c(1, 3, 1, 2, 3, 2, 2, 1, 2)
## g = c(0, 7, 0, 5, 7, 5, 5, 0, 5)
## g = c('A', 'C', 'A', 'B', 'C', 'B', 'B', 'A', 'B')
## g = c("paul", "jack", "paul", "susan", "jack", "susan", "susan", "paul", "susan")


## ------------------------------------------------------------------------
v = c(2, 2, 6, 8, 9, 1, 2, 7, 5) 
g = c(1, 3, 1, 2, 3, 2, 2, 1, 2) 
tapply(v, g, FUN = mean) 


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- tidy=FALSE---------------------------------------------------------
dat <- data.frame(gender=c('M','M','M','M','M','F','F','F','F','F'),
                  num=c(1,2,3,1,2,3,1,2,3,1),
                  h=c(170,180,190,180,170,150,160,170,160,150),
                  w=c(80,70,100,80,60,50,50,60,60,50))
dat$BMI <- dat$w/(dat$h/100)^2
table(dat$gender, dat$num)
tapply(dat$h, list(dat$gender, dat$num), mean)
aggregate(h~gender+num, sum, data=dat)
aggregate(h+w~gender+num, sum, data=dat)
aggregate(cbind(h,w)~gender+num, sum, data=dat)
aggregate(.~gender+num, sum, data=dat)
aggregate(dat, list(dat$gender, dat$num), length)


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## by(dat, list(dat$gender, dat$num), summary)
## ## : F
## ## : 1
## ##  gender      num          h               w           BMI
## ##  F:2    Min.   :1   Min.   :150.0   Min.   :50   Min.   :19.53
## ##  M:0    1st Qu.:1   1st Qu.:152.5   1st Qu.:50   1st Qu.:20.20
## ##         Median :1   Median :155.0   Median :50   Median :20.88
## ##         Mean   :1   Mean   :155.0   Mean   :50   Mean   :20.88
## ##         3rd Qu.:1   3rd Qu.:157.5   3rd Qu.:50   3rd Qu.:21.55
## ##         Max.   :1   Max.   :160.0   Max.   :50   Max.   :22.22
## ## --------------------------------------------------------
## ## : M
## ## : 1
## ##  gender      num          h               w           BMI
## ##  F:0    Min.   :1   Min.   :170.0   Min.   :80   Min.   :24.69
## ##  M:2    1st Qu.:1   1st Qu.:172.5   1st Qu.:80   1st Qu.:25.44
## ##         Median :1   Median :175.0   Median :80   Median :26.19
## ##         Mean   :1   Mean   :175.0   Mean   :80   Mean   :26.19
## ## ...

## ---- eval=F, include=F--------------------------------------------------
## ##         3rd Qu.:1   3rd Qu.:177.5   3rd Qu.:80   3rd Qu.:26.93
## ##         Max.   :1   Max.   :180.0   Max.   :80   Max.   :27.68
## 
## ## --------------------------------------------------------
## ## ...


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
library(dplyr)
options(stringsAsFactors=F)
dfCustomer <- data.frame(
  id = c(1,2,3,4,5),
  name = c("김희선","박보검","설현","김수현","전지현"),
  addr = c("서울시","부산시","인천시","강릉시","목포시")
)
dfPurchase <- data.frame(
  name = c("김희선","박보검","김희선","설현","김수현","박보검"),
  product = c("바지","샴푸","텔레비전","바지","바지","샴푸")
)
dfProduct <- data.frame(
  product = c("샴푸","텔레비전","바지"),
  price =c(13800, 560000,80000)
)

knitr::kable(left_join(dfPurchase, dfProduct), booktabs=TRUE, 
             caption='소비자의 구매목록', longtable=FALSE)


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
knitr::kable(list(dfPurchase, dfProduct),
             booktabs=TRUE, longtable=FALSE,
             caption='소비자의 구매목록과 상품목록')
#knitr::kable(dfProduct)


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
dfCustomer <- data.frame(
  id = c(1,2,3,4,5),
  name = c("김희선","박보검","설현","김수현","전지현"),
  addr = c("서울시","부산시","인천시","강릉시","목포시"),
  phonenumber = c('0104432332', '0106642632', '01059382', '0109958372', '0102929484')
)
knitr::kable(list(dfCustomer[,(1:2)], dfCustomer[,(3:4)]),
             booktabs=TRUE,  longtable=FALSE,
             caption='동일한 행 갯수, 다른 변수를 가진 두 데이터프레임')
#knitr::kable(dfCustomer[,(3:4)])


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
x <- dfCustomer[1:3, ]; y <- dfCustomer[4:5,]
knitr::kable(list(x, y),
             booktabs=TRUE,  longtable=FALSE,
             caption='열의 갯수가 동일하고 동일한 변수를 저장하고 있는 두 데이터프레임')
#knitr::kable(dfCustomer[1:3,])
#knitr::kable(dfCustomer[-(1:3),])


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
x <- dfCustomer[1:3,c(1,2,3,4)]
y <- dfCustomer[-(1:3),c(2,3,1)]
knitr::kable(list(x,
                  y),
             booktabs=TRUE,  longtable=FALSE,
             caption='동일한 열이름, 다른 순서')
#knitr::kable(dfCustomer[1:3,c(1,2,3,4)])
#knitr::kable(dfCustomer[-(1:3),c(2,3,1)])


## ---- eval=FALSE---------------------------------------------------------
## data.table::rbindlist(list(DF1,DF2), fill=TRUE)
## dplyr::bind_rows(DF1, DF2)


## ---- eval=FALSE---------------------------------------------------------
## colnames(DF2) <- colnames(DF1)


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
#knitr::kable(dfCustomer[c(1,5,4,3,2),c(2,3)])
#knitr::kable(dfCustomer[c(2,4,3,5,1),c(2,4)])
knitr::kable(list(dfCustomer[c(1,5,4,3,2),c(2,3)],
                  dfCustomer[c(2,4,3,5,1),c(2,4)]),
             booktabs=TRUE, longtable=FALSE,
             caption='행의 순서가 다른 두 데이터프레임')


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
#knitr::kable(dfCustomer[c(1,4,3,2),c(2,3)])
#knitr::kable(dfCustomer[c(2,5,1),c(2,4)])
knitr::kable(list(dfCustomer[c(1,4,3,2),c(2,3)],
                  dfCustomer[c(2,5,1),c(2,4)]),
             booktabs=TRUE, longtable=FALSE,
             caption='행을 1대1 대응할 수 없는 두 데이터프레임')


## ----echo=FALSE, message=FALSE, warning=FALSE, tidy=FALSE----------------
DF1 <- dfCustomer1 <- data.frame(
  id = c(3,4,1,5,2),
  name = c("김희선","박보검","설현","김수현","전지현"),
  phonenumber = c('0104432332', '0106642632', '01059382', '0109958372', '0102929484')
)

DF2 <- dfCustomer2 <- data.frame(
  id = c(2,3,4,5), 
  name = c("박보검","설현","김수현","전지현"),
  addr = c("부산시","인천시","강릉시","목포시")
)

#knitr::kable(dfCustomer1 %>% arrange(id))
#knitr::kable(dfCustomer2 %>% arrange(id))
knitr::kable(list(dfCustomer1 %>% arrange(id),
                  dfCustomer2 %>% arrange(id)),
             booktabs=TRUE,  longtable=FALSE,
             caption='name과 id가 다른 두 데이터프레임')


## ------------------------------------------------------------------------
full_join(DF1, DF2)
full_join(DF1, DF2, by='name')


## ---- include=F----------------------------------------------------------
linespread=1.4


## ---- include=F----------------------------------------------------------
linespread=1.2


## ----message=FALSE, warning=FALSE----------------------------------------
library(dplyr)
library(tidyr)
mtcars$name = rownames(mtcars); rownames(mtcars) = NULL
mtcars %>% select(name, mpg, cyl, disp) -> mtcars01
head(mtcars01, 4)


## ------------------------------------------------------------------------
mtcars01 %>% gather(key='key', value='value', mpg, cyl, disp) -> mtcarsLong
head(mtcarsLong, 4)


## ---- include=F----------------------------------------------------------
linespread=1.2


## ------------------------------------------------------------------------
mtcarsLong %>% spread(key='key', value='value') -> mtcars02
head(mtcars02, 4)


## ------------------------------------------------------------------------
all.equal(mtcars01, mtcars02)


## ---- tidy=FALSE---------------------------------------------------------
all.equal(mtcars01 %>% arrange(name), 
          mtcars02 %>% select(name, mpg, cyl, disp) %>% arrange(name))


## ---- tidy=FALSE, results='hold'-----------------------------------------
library(reshape2)
mtcarsLong <- 
  mtcars %>% gather(-name, -am, 
                    mpg, cyl, disp, 
                    key='key', value='value', 
                    factor_key=TRUE) 
mtcarsWide <- 
  mtcarsLong %>% spread(key='key', value='value') 

mtcarsLong2 <- 
  mtcars %>% melt(id=c("name","am"),
                  measure.vars = c("mpg", "cyl", "disp"),
                  variable.name = "key", value.name = 'value')
mtcarsWide2 <- 
  mtcarsLong2 %>% dcast(name + am ~ key) -> mtcarsWide2

all.equal(mtcarsLong, mtcarsLong2)
all.equal(mtcarsWide, mtcarsWide2)


## ------------------------------------------------------------------------
dcast(mtcarsLong2, am ~ key, fun.aggregate=mean)


## ------------------------------------------------------------------------
dcast(mtcarsLong2, name + am ~ key, fun.aggregate=mean) %>% head(5)


## ------------------------------------------------------------------------
dcast(mtcarsLong2, key ~ am, fun.aggregate=mean)
dcast(mtcarsLong2, . ~ am + key, fun.aggregate=mean)
dcast(mtcarsLong2, . ~ key + am, fun.aggregate=mean)
dcast(mtcarsLong2, am + key ~ ., fun.aggregate=mean)

