## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- include=FALSE------------------------------------------------------
#w <- options("width")
#w.tib <- options("tibble.width")
options("width"=80)
options("tibble.width"=80)
options("max.print"=100)
knitr::opts_chunk$set(tidy.opts=list(width.cutoff=80, indent = 2), tidy = TRUE)

## ----message=FALSE, warning=FALSE, tidy=FALSE----------------------------
library(dplyr)
library(data.table)
data(mtcars)
df <- mtcars
TB <- as_tibble(mtcars, rownames='rn')
# rownames='rn'으로 하면 행이름을 열 rn으로 보존한다.
DT <- as.data.table(mtcars, keep.rownames=TRUE) 
# keep.rownames = TRUE 로 놓으면 행이름이 열 rn으로 보존된다.
# 데이터테이블과 티블은 행이름(rownames)를 지원하지 않는다.

print(head(TB))
print(head(DT))


## ---- include=F----------------------------------------------------------
linespread=1.3


## ---- slice, eval=F------------------------------------------------------
## TB %>% slice(3)
## DT[3, ]
## DT[3]

## ---- echo=F-------------------------------------------------------------
DT[3]


## ---- eval=F-------------------------------------------------------------
## TB %>% slice(c(3,5))
## DT[c(3,5),]
## DT[c(3,5)]

## ---- echo=F-------------------------------------------------------------
DT[c(3,5)]


## ---- eval=F-------------------------------------------------------------
## rows <- c(1,5,6)
## TB %>% slice(rows)
## DT[rows,]
## DT[rows]

## ---- echo=F-------------------------------------------------------------
rows <- c(1,5,6)
DT[rows]


## ---- filter, eval=F-----------------------------------------------------
## # cyl==4(실린더가 4개)이고 gear==5 인 행
## mtcars[mtcars$cyl==4 & mtcars$gear==5,]
## TB %>% filter(cyl==4 & gear==5)
## DT[cyl==4 & gear==5,]
## DT[cyl==4 & gear==5]

## ---- echo=F-------------------------------------------------------------
# cyl==4(실린더가 4개)이고 gear==5 인 행 
DT[cyl==4 & gear==5]


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## coln <- c("cyl", "gear")
## conds <- c("==4", "==5")
## cond <- parse(text=paste0(coln, conds, collapse=" & "))
## 
## mtcars[with(mtcars, eval(cond)),]
## TB %>% filter(eval(cond))
## DT[eval(cond),]
## DT[eval(cond)]
## DT[get(coln[1])==4 & get(coln[2])==5]

## ---- echo=FALSE---------------------------------------------------------
coln <- c("cyl", "gear")
conds <- c("==4", "==5")
cond <- parse(text=paste0(coln, conds, collapse=" & "))
#mtcars[with(mtcars, eval(cond)),]
#TB %>% filter(eval(cond))
#DT[eval(cond),]
#DT[eval(cond)]
DT[get(coln[1])==4 & get(coln[2])==5]


## ---- include=F----------------------------------------------------------
linespread=1.3


## ----eval=FALSE----------------------------------------------------------
## DF2 <- mtcars[2:3,]; # 데이터프레임(data.frame)
## TB2 <- as_tibble(TB) %>% slice(2:3) # 티블(tibble)
## DT2 <- DT[2:3,] # 데이터테이블(data.table)

## ----include=FALSE-------------------------------------------------------
DF2 <- mtcars[2:3,];
TB2 <- as_tibble(TB) %>% slice(2:3)
DT2 <- DT[2:3,]


## ---- eval=FALSE---------------------------------------------------------
## DF2[,c(3,5)]
## TB2 %>% select(c(3,5))
## DT2[, c(3,5)]

## ---- echo=F-------------------------------------------------------------
DT2[, c(3,5)]


## ---- eval=F-------------------------------------------------------------
## DF2[,c("cyl", "hp")]
## TB2 %>% select(c(cyl, hp))
## DT2[, .(cyl, hp)]

## ---- echo=F-------------------------------------------------------------
DT2[, .(cyl, hp)]


## ---- include=F----------------------------------------------------------
linespread=1.2
linespreadcode=1.05


## ---- eval=FALSE---------------------------------------------------------
## icols = c(3,5)
## DF2[, icols]
## TB2 %>% select(icols)
## DT2[, ..icols]

## ---- echo=F-------------------------------------------------------------
icols = c(3,5)
DT2[, ..icols]


## ---- eval=F-------------------------------------------------------------
## nacols = c('cyl', 'hp')
## DF2[, nacols]
## TB2 %>% select_at(nacols)
## DT2[, ..nacols]

## ---- echo=F-------------------------------------------------------------
nacols = c('cyl', 'hp')
DT2[, ..nacols]


## ---- select02, eval=F---------------------------------------------------
## ## 순번으로 선택
## DT2[, 3] #데이터테이블
## DT2[ ,3][[1]] #벡터

## ---- echo=F-------------------------------------------------------------
DT2[ ,3][[1]] #벡터


## ---- eval=F-------------------------------------------------------------
## ## 이름으로 선택
## DT2[, .(cyl)] #데이터테이블
## DT2[, cyl] # 벡터

## ---- echo=F-------------------------------------------------------------
DT2[, cyl] # 벡터


## ---- eval=F-------------------------------------------------------------
## ## 변수로 순번 선택
## irows = c(3)
## DT2[, ..irows] #데이터테이블
## DT2[, ..irows][[1]] #벡터

## ---- echo=F-------------------------------------------------------------
irows = c(3) 
DT2[, ..irows][[1]] #벡터


## ---- eval=F-------------------------------------------------------------
## ## 변수로 열이름 선택
## nrows = c('cyl')
## DT2[, ..nrows] # 데이터테이블
## DT2[, ..nrows][[1]] #벡터

## ---- echo=F-------------------------------------------------------------
nrows = c('cyl') 
DT2[, ..nrows][[1]] #벡터


## ---- include=F----------------------------------------------------------
linespread=1.3
linespreadcode=1.1


## ---- eval=F-------------------------------------------------------------
## DT2[, -c(3,4)] # 순번으로 열 제외
## icols = c(3,4) # 순번 변수로 열 제외
## DT2[, -..icols]; DT2[, !..icols]

## ---- echo=F-------------------------------------------------------------
#DT2[, -c(3,4)] # 순번으로 열 제외
icols = c(3,4) # 순번 변수로 열 제외
DT2[, -..icols];


## ---- eval=F-------------------------------------------------------------
## coln = c('cyl', 'disp') # 열이름 변수로 열 제외
## DT2[, !..coln]
## DT2[, .SD, .SDcols=coln2]

## ---- echo=F-------------------------------------------------------------
coln = c('cyl', 'disp') # 열이름 변수로 열 제외
DT2[, !..coln]


## ---- include=F----------------------------------------------------------
linespread=1.3


## ---- mutate-------------------------------------------------------------
# 데이터
DF3 <- DF2[ , c("hp", "qsec")]
TB3 <- TB2 %>% select(hp, qsec)
DT3 <- DT2[, .(hp, qsec)]


## ---- eval=FALSE---------------------------------------------------------
## DF3[ ,"wt2"] = DF3$hp * DF3$qsec
## DF3$wt2 = DF3$hp * DF3$qsec
## DF3[["wt2"]] = DF3$hp * DF3$qsec
## TB3 %>% mutate(wt2 = hp*qsec)
## DT3[, wt2:=hp*qsec]; print(DT3)

## ---- echo=FALSE---------------------------------------------------------
DT3[, wt2:=hp*qsec]; print(DT3)


## ---- eval=FALSE---------------------------------------------------------
## DF3[ ,c("hp", "qsec")] = data.frame(DF3$hp*2, DF3$qsec*2)
## TB3 <- TB3 %>% mutate(hp = hp*2, qsec = qsec*2)
## DT3[, c("hp", "qsec") := list(hp*2, qsec*2)]
## DT3[, `:=`(hp = hp*2,
##            qsec = qsec*2)]
## print(DT3)

## ---- echo=FALSE---------------------------------------------------------
DT3[, `:=`(hp = hp*2,
           qsec = qsec*2)]
print(DT3)


## ---- eval=FALSE---------------------------------------------------------
## coln = 'wt2'
## DF3[ ,coln] = DF3$hp * DF3$qsec
## DF3[[coln]] = DF3$hp * DF3$qsec
## TB3 <- TB2 %>% mutate_at(coln, funs(hp*qsec))
## DT3[, c(coln):=hp*qsec]

## ---- echo=FALSE---------------------------------------------------------
DT3[, c(coln):=hp*qsec]; print(DT3)


## ---- eval=FALSE---------------------------------------------------------
## coln = c('hp', 'qsec')
## DF3[, coln] = lapply(DF3[,coln], function(x) x*2)
## DF3[, coln] = do.call(data.frame, lapply(DF3[,coln], function(x) x*2))
## TB3 <- TB3 %>% mutate_at(coln, funs(.*2))
## DT3[, c(coln):=lapply(.SD, function(x) x*2), .SDcols=coln]
## print(DT3)

## ---- echo=FALSE---------------------------------------------------------
DT3[, c(coln):=lapply(.SD, function(x) x*2), .SDcols=coln]
print(DT3)


## ---- transmute, eval=FALSE, tidy=FALSE----------------------------------
## DF4 = data.frame(wt2 = DF3$hp * DF3$qsec)
## TB4 <- TB3 %>% transmute(wt2 = hp*qsec)
## DT4 <- DT3[, .(wt3=hp*qsec)]; print(DT4)

## ---- echo=FALSE---------------------------------------------------------
DT4 <- DT3[, .(wt3=hp*qsec)]; print(DT4)


## ---- eval=FALSE---------------------------------------------------------
## DF4 = data.frame(hp2 = DF3$hp*2, qsec2 = DF3$qsec*2)
## DF4 = with(DF3, data.frame(hp2 = hp*2, qsec2 = qsec*2))
## TB4 <- TB3 %>% transmute(hp = hp*2, qsec = qsec*2)
## TB4 <- TB3 %>% transmute_at(c('hp', 'qsec'), funs(.*2))
## DT4 <- DT3[, .(hp2=hp*2, qsec2=qsec*2)]
## DT4 <- DT3[, lapply(.SD, function(x) x*2), .SDcols=c('hp', 'qsec')]
## print(DT4)

## ---- echo=FALSE---------------------------------------------------------
DT4 <- DT3[, lapply(.SD, function(x) x*2), .SDcols=c('hp', 'qsec')]
print(DT4)


## ---- eval=FALSE---------------------------------------------------------
## coln = 'wt2'
## DF4 = data.frame(DF3$hp * DF3$qsec); colnames(DF4) = coln
## TB4 <- TB3 %>% transmute(hp*qsec); colnames(TB4) = coln
## DT4 <- DT3[, .(hp*qsec)]; colnames(DT4) = coln
## print(DT4)

## ---- echo=FALSE---------------------------------------------------------
coln = 'wt2'
#DF4 = data.frame(DF3$hp * DF3$qsec); colnames(DF3) = coln
#TB4 <- TB3 %>% transmute(hp*qsec); colnames(TB3) = coln
DT4 <- DT3[, .(hp*qsec)]; colnames(DT4) = coln
print(DT4)


## ------------------------------------------------------------------------
coln = c('hp', 'qsec')
DF4 <- do.call(data.frame, lapply(DF3[,coln], function(x) x*2))
TB4 <- TB3 %>% transmute_at(coln, funs(.*2))
DT4 <- DT3[, lapply(.SD, function(x) x*2), .SDcols=coln]
print(DT4)


## ---- eval=FALSE---------------------------------------------------------
## DF5 <- mtcars[c(2:5), 1:4]
## TB5 <- as_tibble(mtcars) %>% slice(2:5) %>% select(1:4)
## DT5 <- as.data.table(mtcars, keep.rownames=TRUE)[2:5, c(1:4)]
## print(DT5)

## ----message=FALSE, warning=FALSE, echo=FALSE----------------------------
library(dplyr)
library(data.table)
DF5 <- mtcars[c(2:5), 1:4]
TB5 <- as_tibble(mtcars) %>% slice(2:5) %>% select(1:4)
DT5 <- as.data.table(mtcars, keep.rownames=TRUE)[2:5, c(1:4)]
print(head(DT5))


## ---- arrange, eval=FALSE, tidy=FALSE------------------------------------
## DF5[order(DF5$cyl, -DF5$mpg),]
## TB5 %>% arrange(cyl, desc(mpg))
## DT5[order(cyl, -mpg),]; DT5[order(cyl, -mpg)]

## ---- echo=FALSE---------------------------------------------------------
DT5[order(cyl, -mpg)]


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- group_by-----------------------------------------------------------
DF6 <- mtcars[c(10:2), c("mpg", "cyl", "disp","hp", "am")]
TB6 <- TB %>% slice(10:2) %>% select(mpg, cyl, disp, hp, am)
DT6 <- DT[10:2, .(mpg, cyl, disp, hp, am)]
print(head(DT6))


## ---- eval=FALSE---------------------------------------------------------
## aggregate(mpg ~ cyl, data=DF6, FUN=mean)
## TB6 %>% group_by(cyl) %>% summarise(mpg=mean(mpg))
## DT6[, mean(mpg), cyl] # cyl는 정렬되지 않는다.
## DT6[, .(mpg=mean(mpg)), by=cyl] # cyl는 정렬되지 않는다.
## DT6[, mean(mpg), keyby=cyl] # cyl는 정렬된다.

## ---- echo=FALSE---------------------------------------------------------
DT6[, .(mpg=mean(mpg)), by=cyl] # data.table, cyl is not sorted
DT6[, mean(mpg), keyby=cyl] # data.table, cyl is sorted


## ---- include=F----------------------------------------------------------
linespread=1.3


## ----eval=FALSE, include=FALSE-------------------------------------------
## aggregate(cbind(mpg, hp) ~ cyl, data=DF6, FUN=mean)
## TB6 %>% group_by(cyl) %>% summarise(mpg=mean(mpg), hp=mean(hp))
## DT6[, .(mpg = mean(mpg), hp = mean(hp)), by=cyl] # data.table, cyl is not sorted
## DT6[, .(mpg = mean(mpg), hp = mean(hp)), keyby=cyl] # data.table, cyl is sorted

## ---- eval=FALSE---------------------------------------------------------
## aggregate(cbind(mpg, hp) ~ am + cyl, data=DF6, FUN=mean)
## TB6 %>% group_by(cyl, am) %>% summarise(mpg=mean(mpg), hp=mean(hp))
## DT6[, .(mpg = mean(mpg), hp = mean(hp)), by=.(cyl, am)]
## DT6[, .(mpg = mean(mpg), hp = mean(hp)), keyby=.(cyl, am)]

## ---- echo=FALSE---------------------------------------------------------
aggregate(cbind(mpg, hp) ~ am + cyl, data=DF6, FUN=mean) 
TB6 %>% group_by(cyl, am) %>% summarise(mpg=mean(mpg), hp=mean(hp)) 
DT6[, .(mpg = mean(mpg), hp = mean(hp)), by=.(cyl, am)] 
DT6[, .(mpg = mean(mpg), hp = mean(hp)), keyby=.(cyl, am)] 


## ---- eval=FALSE---------------------------------------------------------
## aggregate(. ~ am + cyl, data=DF6, FUN=mean)
## TB6 %>% group_by(cyl, am) %>% summarise_all(mean)
## DT6[, lapply(.SD, mean), by=.(cyl, am)] # cyl, am에 대해 정렬되지 않음
## DT6[, lapply(.SD, mean), keyby=.(cyl, am)] # cyl, am에 대해 정렬

## ---- echo=FALSE---------------------------------------------------------
#aggregate(. ~ am + cyl, data=DF6, FUN=mean) 
#TB6 %>% group_by(cyl, am) %>% summarise_all(mean) 
DT6[, lapply(.SD, mean), .(cyl, am)] 
DT6[, lapply(.SD, mean), keyby=.(cyl, am)] 


## ---- eval=FALSE, echo=FALSE---------------------------------------------
## res <- do.call(rbind, by(DF6, list(DF6$cyl), FUN=head, n=2)) # data.frame
## # data.table::rbindlist
## res <- rbindlist(by(DF6, list(DF6$cyl), FUN=head, n=2))
## # do 안의 .은 %>% 이전의 결과(TB6 %>% group_by(cyl))
## TB6 %>% group_by(cyl) %>% do(head(., n=2))
## DT6[, head(.SD, n=2), by=cyl] # data.table
## DT6[, head(.SD, n=2), keyby=cyl] # data.table


## ---- group_by02, tidy=FALSE, eval=FALSE---------------------------------
## DF6 <- aggregate(cbind(mpg, hp) ~ am + cyl, data=DF6, FUN=mean);
## DF6[order(DF6$mpg),]
## TB6 %>% group_by(cyl, am) %>% summarise(mpg=mean(mpg), hp=mean(hp)) %>%
##   arrange(mpg)
## DT6[, .(mpg = mean(mpg), hp = mean(hp)), by=.(cyl, am)][order(mpg)]
## DT6[, .(mpg = mean(mpg), hp = mean(hp)), keyby=.(cyl, am)][order(mpg)]

## ---- echo=FALSE---------------------------------------------------------
#DF6 <- aggregate(cbind(mpg, hp) ~ am + cyl, data=DF6, FUN=mean);
#DF6[order(DF6$mpg),] 
#TB6 %>% group_by(cyl, am) %>% summarise(mpg=mean(mpg), hp=mean(hp)) %>%
#  arrange(mpg) 
DT6[, .(mpg = mean(mpg), hp = mean(hp)), by=.(cyl, am)][order(mpg)]
DT6[, .(mpg = mean(mpg), hp = mean(hp)), keyby=.(cyl, am)][order(mpg)] 


## ---- example, eval=F----------------------------------------------------
## example(data.table)


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## DF7 <- mtcars[c(2:10), c(1,8:10)]
## 
## TB7 <- as_tibble(mtcars, rownames='rn') %>%
##   slice(2:10) %>%
##   select(c(1, 8:10))
## 
## DT7 <- as.data.table(mtcars, keep.rownames=TRUE)[2:10, c(1, 8:10)]
## DT7[,amch:=ifelse(am==1, "Automatic", "Manual")]
## DT7[,vsch:=ifelse(vs==0, "V-shaped", "straight")]
## 
## print(head(TB7))
## print(head(DT7))

## ----message=TRUE, warning=FALSE, echo=FALSE-----------------------------
library(dplyr)
library(data.table)
rm(DT, DT2, DT3, DT4, DT5, DT6)
DF7 <- mtcars[c(2:10), c(1,8:10)]
TB7 <- as_tibble(mtcars, rownames='rn') %>% slice(2:10) %>% select(c(1, 8:10))
DT7 <- as.data.table(mtcars, keep.rownames=TRUE)[2:10, c(1, 8:10)]
DT7[,amch:=ifelse(am==1, "Automatic", "Manual")]
DT7[,vsch:=ifelse(vs==0, "V-shaped", "straight")]
DT8 <- DT7
print(head(TB7))
print(head(DT7))


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- tidy=FALSE---------------------------------------------------------
key(DT7)
setkey(DT7, qsec)
haskey(DT7); key(DT7)
tables()
setkey(DT8, am, vsch)
key(DT8)
coln <- c("am", "vsch")
setkeyv(DT8, coln)
key(DT8)
tables()


## ---- include=F----------------------------------------------------------
linespread=1.3


## ---- J------------------------------------------------------------------
DT8[J(1),]
DT8[am == 1,]
DT8[amch == "Automatic",]

DT8[J(1,"straight"),]
DT8[am == 1 & vsch == "straight",]

DT8[am >= 0, ]


## ------------------------------------------------------------------------
DT8[J(1), mult='first']
DT8[J(1), mult='last']
DT8[J(1), mult='all'] # DT8[J(1)]


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## dt1 <- data.table(
##   id = c(1,NA,3,4,4,5,6,6),
##   x = c('1','2','3','4a','4b','5','6a','6b')
## )
## 
## dt2 <- data.table(
##   id = c(NA,2,3,4,5,5,6,6),
##   y = c('1','2','3','4a','5a','5b','6a','6b')
## )

## ----dt4, results='hold', echo=FALSE-------------------------------------
dt1 <- data.table(
  id = c(1,NA,3,4,4,5,6,6),
  x = c('1','2','3','4a','4b','5','6a','6b')
)

dt2 <- data.table(
  id = c(NA,2,3,4,5,5,6,6),
  y = c('1','2','3','4a','5a','5b','6a','6b')
)

#knitr::kable(list(dt1[dt2, on='id'],
#                  {setkey(dt1, id)
#                    dt1[J(dt2$id), ]}),
#             longtable=TRUE,
#             booktabs=TRUE,
#             caption='dt1과 dt2')


## ---- eval=FALSE---------------------------------------------------------
## dt1[dt2, on='id']
## setkey(dt1, id); dt1[J(dt2$id), ]


## ---- include=F----------------------------------------------------------
linespread=1.3


## ----message=FALSE, warning=FALSE, tidy=FALSE----------------------------
library(dplyr)
library(data.table)

TBA <- as_tibble(mtcars, rownames='rn') %>% 
  slice(3:4) %>% 
  select(1:4)
TBB <- as_tibble(mtcars, rownames='rn') %>% 
  slice(4:5) %>% 
  select(1, 8:10)

DTA <- as.data.table(mtcars, keep.rownames=TRUE)[3:4, c(1:4)]
DTB <- as.data.table(mtcars, keep.rownames=TRUE)[4:5, c(1, 8:10)]

print(DTA)
print(DTB)

## ----dt1, echo=FALSE, eval=FALSE-----------------------------------------
## #x <- head(DTA)
## #y <- head(DTB)
## #knitr::kable(list(x,y),
## #             booktabs=TRUE,
## #             #longtable=TRUE,
## #             caption='DTA과 DTB'
## #            )
## #print(head(TBA))
## #print(head(TBB))


## ---- join, eval=FALSE---------------------------------------------------
## inner_join(TBA, TBB, by='rn')
## DTA[DTB, on='rn', nomatch=0]
## merge(DTA, DTB, by='rn', all=FALSE) # merge.data.table

## ---- echo=FALSE---------------------------------------------------------
merge(DTA, DTB, by='rn', all=FALSE) # merge.data.table


## ---- eval=FALSE---------------------------------------------------------
## full_join(TBA, TBB, by='rn')
## merge(DTA, DTB, by='rn', all=TRUE)

## ---- echo=FALSE---------------------------------------------------------
merge(DTA, DTB, by='rn', all=TRUE)


## ---- eval=FALSE---------------------------------------------------------
## left_join(TBA, TBB, by='rn')
## DTB[DTA, on='rn']
## #merge에서 x는 첫 번째 데이터프레임, y는 두 번째 데이터프레임
## merge(DTA, DTB, by='rn', all.x=TRUE)

## ---- echo=FALSE---------------------------------------------------------
DTB[DTA, on='rn']
merge(DTA, DTB, by='rn', all.x=TRUE)


## ---- eval=FALSE---------------------------------------------------------
## right_join(TBA, TBB, by='rn')
## DTA[DTB, on='rn']
## merge(DTA, DTB, by='rn', all.y=TRUE)

## ---- echo=FALSE---------------------------------------------------------
merge(DTA, DTB, by='rn', all.y=TRUE)


## ---- eval=FALSE---------------------------------------------------------
## semi_join(TBA, TBB, by='rn')
## DTA[DTB, .SD, on='rn']

## ---- echo=FALSE---------------------------------------------------------
DTA[DTB, .SD, on='rn']


## ---- eval=FALSE---------------------------------------------------------
## anti_join(TBA, TBB, by='rn')
## DTA[!DTB, .SD, on='rn']

## ---- echo=FALSE---------------------------------------------------------
DTA[!DTB, .SD, on='rn']


## ------------------------------------------------------------------------
DF <- data.frame(rn=rownames(mtcars), mtcars)

TBA<- as_tibble(DF) %>% slice(3:4) %>% select(1:4)
TBB <- as_tibble(DF) %>% slice(4:7) %>% select(1, 3, 9:10)

DTA <- as.data.table(DF)[3:4, c(1:4)]
DTB <- as.data.table(DF)[4:7, c(1, 3, 9:10)]

print(DTA)
print(DTB)

## ----dt2, echo=FALSE-----------------------------------------------------
#knitr::kable(list(head(DTA),
#                  head(DTB)),
#             #longtable=TRUE,
#             booktabs=TRUE,
#             caption='DTA과 DTB'
#            )
#print(head(TBA))
#print(head(TBB))


## ----eval=FALSE, include=FALSE, join2, eval=FALSE------------------------
## inner_join(TBA, TBB, by='cyl')
## DTA[DTB, on='cyl', nomatch=0]
## #DTB[DTA, on='cyl', nomatch=0, mult='first']
## #DTB[DTA, on='cyl', nomatch=0, mult='last']
## 
## #DTA[DTB, on='cyl']
## #DTA[DTB, on='cyl', mult='first']
## #DTA[DTB, on='cyl', mult='last']
## 
## full_join(TBA, TBB, by='cyl')
## merge(DTA, DTB, by='cyl', all=TRUE) # merge.data.table
## 
## left_join(TBA, TBB, by='cyl')
## DTB[DTA, on='cyl']
## 
## right_join(TBA, TBB, by='cyl')
## DTA[DTB, on='cyl']
## 
## semi_join(TBA, TBB, by='cyl')
## DTA[DTB, .SD, on='cyl']
## 
## anti_join(TBA, TBB, by='cyl')
## DTA[!DTB, .SD, on='cyl']


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## inner_join(TBA, TBB, by='cyl')
## DTA[DTB, on='cyl']

## ---- echo=FALSE---------------------------------------------------------
DTA[DTB, on='cyl']


## ---- join3--------------------------------------------------------------
setkey(DTA, rn)
setkey(DTB, rn)
DTA[DTB]


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## DT1[DT2, on='key'][, .SD[1], by='key']
## # =`DT1[DT2, on='key', mult='first']`
## DT1[DT2, on='key'][, .SD[.N], by='key']
## # = DT1[DT2, on='key', mult='last']`


## ----join_mult, results='hold', tidy=FALSE-------------------------------
#inner_join(TBA, TBB, by='cyl')
#inner_join(TBA, TBB, by='cyl') %>% group_by(cyl) %>% .[1,]
#inner_join(TBA, TBB, by='cyl') %>% group_by(cyl) %>% .[nrow(.),]
DTB[DTA, on='cyl', nomatch=0]
DTB[DTA, on='cyl', nomatch=0, mult='first']
DTB[DTA, on='cyl', nomatch=0, mult='last']


## ---- results='hold', tidy=FALSE-----------------------------------------
#left_join(TBA, TBB, by='cyl')
#left_join(TBA, TBB, by='cyl') %>% group_by(cyl) %>% do(head(., n=1))
#left_join(TBA, TBB, by='cyl') %>% group_by(cyl) %>% do(tail(., n=1))
DTB[DTA, on='cyl'] 
DTB[DTA, on='cyl', mult='first']
DTB[DTA, on='cyl', mult='last']


## ---- tidy='FALSE'-------------------------------------------------------
DTA = data.table(
  date = as.Date(c('2018-12-31', '2019-1-4', '2019-1-9')),
  duration = c(60, 30, 40))
DTB = data.table(
  date = as.Date(c('2018-1-2', '2019-1-5', '2019-1-6')),
  product = c('Cosmetics', 'Toys', 'Books'))

## ----dt3, echo=FALSE-----------------------------------------------------
knitr::kable(list(head(DTA),
                  head(DTB)),
             #longtable=TRUE,
             booktabs=TRUE,
             caption='DTA과 DTB'
            )
#print(head(TBA))
#print(head(TBB))


## ------------------------------------------------------------------------
DTB[DTA, on='date', roll=-Inf]


## ------------------------------------------------------------------------
DTB[, datePurchase:=date]
DTB[DTA, on='date', roll=-Inf]


## ------------------------------------------------------------------------
DTB[DTA, on='date', roll=Inf]
DTB[DTA, on='date', roll=3]


## ---- include=F----------------------------------------------------------
linespread=1.2


## ---- data---------------------------------------------------------------
library(dplyr)
library(data.table)
df <- data.frame(rn=rownames(mtcars), mtcars)
TB <- as_tibble(df) %>% slice(3:7) %>% select(1:4)
DT <- as.data.table(mtcars, keep.rownames=TRUE)[3:7, c(1:4)]
print(DT)


## ------------------------------------------------------------------------
TB %>% group_by(cyl) %>% summarise_at(vars(mpg, disp), funs(sum(.)))

## ---- results='hold'-----------------------------------------------------
DT[, lapply(.SD, sum), by=cyl, .SDcols=c('mpg', 'cyl', 'disp')]
#DT[ , lapply(.SD, sum), by=cyl] # 컬럼 rn이 문자이기 때문에 sum을 쓸 수 없다.


## ---- tidy=FALSE---------------------------------------------------------
DT[, .N, by=cyl]
DT[, length(mpg), by=cyl] # 위의 결과와 동일.

DT[, 
   c(.N, lapply(.SD, mean)), 
   by=cyl, 
   .SDcols=c('mpg', 'cyl', 'disp')]
DT[, 
   c(list(N=.N), 
     lapply(.SD, mean)), 
   by=cyl, 
   .SDcols=c('mpg', 'cyl', 'disp')]


## ------------------------------------------------------------------------

DT[, .I, by=cyl]
DT[, .I, keyby=cyl]

DT[, .I[1], by=cyl] 
DT[, .I[1], keyby=cyl]


## ------------------------------------------------------------------------
DT[, .GRP, by=cyl]
DT[, .GRP, keyby=cyl]


## ---- results='hold'-----------------------------------------------------
DT[, .BY, by=cyl]
DT[, lDisp := ifelse(disp<300, '<300', '>=300')]
DT[, c(.BY), by=c('cyl', 'lDisp')]
#DT[, .BY, by=c('cyl', 'lDisp')]


## ---- results='hold'-----------------------------------------------------
DT[, .(cyl[1], lDisp[1]), by=c('cyl', 'lDisp')]
#DT[, .BY, by=c('cyl', 'lDisp')]


## ---- results='hold'-----------------------------------------------------
DT[, do.call(paste0, .BY), by=c('cyl', 'lDisp')]
#DT[, .(grpname = do.call(paste0, .BY)), by=c('cyl', 'lDisp')]


## ------------------------------------------------------------------------
df <- data.frame(rn=rownames(mtcars), mtcars)
TBA <- as_tibble(df) %>% slice(3:10) %>% select(1:4, 9)
TBB <- as_tibble(df) %>% slice(7:10) %>% select(1,3, 8:10)
DTA <- as.data.table(mtcars, keep.rownames=TRUE)[3:10, c(1:4, 9)]
DTB <- as.data.table(mtcars, keep.rownames=TRUE)[7:10, c(1, 3, 8:10)]

DTA[DTB, on='cyl']
DTA[DTB, sum(disp), on='cyl', by='cyl']
DTA[DTB, sum(disp), on='cyl', by=.EACHI]


## ------------------------------------------------------------------------
DTA[DTB, .SD[1], on='cyl', by=.EACHI]
DTA[DTB, on='cyl', mult='first']


## ---- include=FALSE------------------------------------------------------
options("width"=70)
options("tibble.width"=70)
knitr::opts_chunk$set(tidy.opts=list(width.cutoff=70, indent = 2), tidy = TRUE)
linespread=1.2

