## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- include=F----------------------------------------------------------
linespread=1.2
linespreadcode=1.1
linespreadtable=1.0


## ---- include=F----------------------------------------------------------
linespread=1.3


## ------------------------------------------------------------------------
data(diamonds , package='ggplot2')
dim(head(diamonds , n=4)) 


## ------------------------------------------------------------------------
library(magrittr) 
diamonds %>% head(., n=4) %>% dim(.) 


## ------------------------------------------------------------------------
diamonds %>% head(n=4) %>% dim() 


## ------------------------------------------------------------------------
diamonds %>% head(n=4) %>% dim 


## ------------------------------------------------------------------------
diamonds %>% .$price %>% .[1:10]
diamonds %>% .[["price"]] %>% .[1:10]


## ------------------------------------------------------------------------
options(tibble.print_max = 5, tibble.print_min = 5)


## ----message=FALSE, warning=F--------------------------------------------
class(diamonds) 
library(dplyr) 
diamonds 


## ----error=T, results='hold'---------------------------------------------
diaTB <- as_tibble(diamonds[1:10, ]) 
diaDF <- as.data.frame(diamonds[1:10, ]) 
diaDF$pri 
diaDF[, 'pri'] 
diaTB$pri 
diaTB[, 'pri']


## ---- results='hold'-----------------------------------------------------
df <- data.frame(a = c('Kim','Lee','Park'))
tb <- tibble(a = c('Kim','Lee','Park'))
class(df$a)
class(tb$a)


## ---- include=F----------------------------------------------------------
linespread=1.3


## ------------------------------------------------------------------------
library(dplyr)
data(mtcars) 


## ------------------------------------------------------------------------
tb = as_tibble(mtcars) 


## ------------------------------------------------------------------------
tb[2:5, ]
slice(tb, 2:5)


## ---- eval=F-------------------------------------------------------------
## tb %>% .[2:5, ]
## tb %>% slice(., 2:5)


## ---- eval=F-------------------------------------------------------------
## tb %>% slice(2:5)
## tb %>% slice(c(2:3, 4, 5))


## ------------------------------------------------------------------------
tb[tb$mpg>30, ]


## ---- eval=F-------------------------------------------------------------
## filter(tb, mpg>30)
## tb %>% filter(., mpg>30)
## tb %>% filter(mpg>30)


## ---- eval=F-------------------------------------------------------------
## tb <- tb %>% slice(3:5)
## tb[, c(1,3)]
## select(tb, c(1,3))
## tb %>% select(c(1,3))

## ----echo=FALSE----------------------------------------------------------
tb <- tb %>% slice(3:5)
tb[, c(1,3)]


## ---- eval=F-------------------------------------------------------------
## tb[, c("cyl", "hp")]
## select(tb, c("cyl", "hp"))
## select(tb, c(cyl, hp))
## 
## tb %>% select(c("cyl", "hp"))
## tb %>% select(c(cyl, hp))
## 
## tb %>% select("cyl", "hp")
## tb %>% select(cyl, hp)


## ---- collapse = TRUE----------------------------------------------------
which(colnames(tb)=='hp'); which(colnames(tb)=='qsec') 
tb[, which(colnames(tb)=='hp'):which(colnames(tb)=='qsec')] 


## ------------------------------------------------------------------------
tb %>% select(hp:qsec) 


## ----error=T-------------------------------------------------------------
slice(tb, c(1, 2)) 
slice(tb, 1, 2) 


## ------------------------------------------------------------------------
tb3 <- tb %>% slice(1:3) 
tb3 
tb3 %>% select(starts_with('c')) 
tb3 %>% select(starts_with('ca')) 
tb3 %>% select(ends_with('p')) 
tb3 %>% select(contains('c')) 


## ------------------------------------------------------------------------
coln <- c('drat', 'qsec') 
tb3 %>% select(one_of(coln)) 


## ------------------------------------------------------------------------
tb3 %>% select(matches('^(.s|.{4})')) 


## ------------------------------------------------------------------------
tb %>% select(-cyl, -qsec)
tb %>% select(-c(cyl, qsec))


## ------------------------------------------------------------------------
tb %>% select(-starts_with('c'))
tb %>% select(-contains('c'))


## ------------------------------------------------------------------------
library(dplyr)
data(mtcars) 
tb = as_tibble(mtcars) 

tb2 <- tb %>% select(hp, cyl, qsec) %>% slice(1:3)

tb2 %>% mutate(hp/cyl)
tb2 %>% mutate(hpPerCyl = hp/cyl)
tb2 %>% mutate(hpPerCyl = hp/cyl, V2 = hp*qsec)


## ------------------------------------------------------------------------
tb2$`hp/cyl` 
tb3 <- tb2 %>% mutate(hp/cyl) 
tb3$`hp/cyl` 


## ------------------------------------------------------------------------
tb$V2 = with(tb, hp*qsec)
tb[c('V1', 'V2')] = data.frame(tb$hp/tb$cyl, tb$hp*tb$qsec)


## ------------------------------------------------------------------------
tb3 %>% arrange(cyl, desc(qsec))


## ------------------------------------------------------------------------
tb %>% summarise(mean(hp)) 
tb %>% summarize(V1 = mean(hp))
tb %>% summarise(hpMean = mean(hp), qsecMedian =median(qsec))


## ------------------------------------------------------------------------
tb %>% summarise(newVar1 = mean(hp) + median(qsec))
tb %>% summarise(newVar1 = mean(hp), newVar2 = median(qsec))


## ---- error=T------------------------------------------------------------
tb %>% summarise(v1 = mean(hp), v2 = median(qsec), v3 = v1 + v2)
data.frame(v1 = mean(tb$hp), v2 = median(tb$qsec), v3 = v1 + v2)


## ------------------------------------------------------------------------
tb3 %>% group_by(cyl) 
tb3_grp <- tb3 %>% group_by(cyl) 
class(tb3_grp) 


## ------------------------------------------------------------------------
tb %>% group_by(am) %>% summarise(mean(qsec))


## ----error=T, eval=F-----------------------------------------------------
## tb %>% summarise(range(hp))
## 
## ## Error in summarise_impl(.data, dots) :
## ##   Column `range(hp)` must be length 1 (a summary value), not 2


## ------------------------------------------------------------------------
tb %>% group_by(am) %>% do(head(., n=2))


## ---- eval=FALSE---------------------------------------------------------
## tb %>% group_by(am) %>% do(summary(.))
## 
## ## Error in data.frame(v1 = mean(tb$hp), v2 = median(tb$qsec), v3 = v1 +  :
## ##  object 'v1' not found


## ------------------------------------------------------------------------
tb %>% group_by(am) %>% 
  do(as.data.frame(summary(.))) %>% 
  slice(1:3)


## ---- include=F----------------------------------------------------------
linespread=1.2
linespreadcode=1.05
linespreadtable=1.0


## ------------------------------------------------------------------------
library(dplyr)
mtcars %>% mutate(exp(qsec)) %>% head(3)


## ---- tidy=FALSE---------------------------------------------------------
mtcars %>% 
  mutate(expMpg=exp(mpg), expCyl=exp(cyl), expDisp=exp(disp), 
         expHp=exp(hp), expDrat=exp(drat), expWt=exp(wt), 
         expQsec=exp(qsec), expVs=exp(vs), expAm=exp(am), 
         expGear=exp(gear), expCarb=exp(carb)) %>% 
  head(n=3)


## ------------------------------------------------------------------------
mtcars %>% mutate_all(exp) %>% head(n=3) 


## ------------------------------------------------------------------------
options(digits=4)

## ------------------------------------------------------------------------
coln = c('cyl', 'disp', 'drat', 'carb') 
mtcars %>% mutate_at(coln, exp) %>% head(n=3) 


## ---- tidy=FALSE---------------------------------------------------------
mtcars %>% 
  select(starts_with('c'), starts_with('d')) %>% 
  mutate_all(exp) %>% 
  head(n=3)


## ---- tidy=FALSE---------------------------------------------------------
mtcars %>% 
  mutate_at(vars(starts_with('c'), starts_with('d')), 
            exp) %>% 
  head(n=3)


## ---- tidy=FALSE---------------------------------------------------------
mtcars %>% 
  mutate_if(function(x) { sum(x)<100 }, exp ) %>% 
  head(n=3)


## ---- tidy=FALSE, results='hold'-----------------------------------------
mtcars %>% 
  transmute(expCarb = exp(carb)) %>% head(n=3) 
mtcars %>% 
  transmute_if(function(x) { sum(x)<100 }, exp) %>% head(n=3) 


## ---- eval=F-------------------------------------------------------------
## mtcars %>% transmute_if(function(x) sum(x)<100, exp) %>% head(n=3)
## mtcars %>% transmute_if(funs(sum(.) <100), exp) %>% head(n=3)

## ---- echo=F-------------------------------------------------------------
mtcars %>% transmute_if(funs(sum(.) <100), exp) %>% head(n=3) 


## ---- tidy=FALSE---------------------------------------------------------
mtcars %>% 
  mutate_if(funs(sum(.) >= 100), 
            funs(paste(.,"+",sep=""))) %>% head(n=3)
mtcars %>% transmute_at(vars(starts_with('d')), exp) %>% head(n=3)


## ---- include=F----------------------------------------------------------
linespread=1.2
linespreadcode=1.1
linespreadtable=1.0

