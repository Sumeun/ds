## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
# from Class02_ImportingData.Rmd of MJU-2018-02-DataScience
###tags=
###category=


## ----data, collapse=TRUE-------------------------------------------------
data(mtcars)
head(mtcars, n=3)

data("BankWages", package='AER')
head(BankWages, n=3)


## ----intro, collapse=TRUE------------------------------------------------
dat <- mtcars
head(dat, n=3)
class(dat)

write.table(dat, file='dat.txt')
dat02 <- read.table(file='dat.txt')

all.equal(dat, dat02)


## ----intro02, collapse=TRUE, error=TRUE----------------------------------
dat <- mtcars

save(dat, file='dat.RData')
datBackup <- dat
rm(dat)
head(dat)

load(file='dat.RData')

head(dat, n=3)
all.equal(dat, datBackup)
file.size('dat.txt')
file.size('dat.RData')


## ----dataframe, tidy=FALSE-----------------------------------------------
datMsg <- 
  data.frame(
    name = c("BTS", "트와이스", "케이티 킴"),
    phone = c('010-4342-5842', '010-5821-4433', '010-5532-4432'),
    usageLastMonth = c(38000, 58000,31000),
    message = c('안녕, 날씨 좋다! "가즈아!"라고 말하고 싶다.',
                '달빛 아래 춤추자! \'너무너무너무\'라고 노래 부를래.',
                'Memorable'),
    price = c(30, 10, NA), 
    stringsAsFactors=FALSE)
datMsg


## ----readcsv, collapse=T, eval=F-----------------------------------------
## write.csv(datMsg, file='dat.csv')
## datMsg02 <- read.csv(file='dat.csv')
## all.equal(datMsg, datMsg02)
## ## [1] "Names: 5 string mismatches"
## ## [2] "Length mismatch: comparison on first 5 components"
## ## ...

## ----readcsv2, include=FALSE---------------------------------------------
write.csv(datMsg, file='dat.csv')
datMsg02 <- read.csv(file='dat.csv')
all.equal(datMsg, datMsg02)


## ------------------------------------------------------------------------
head(datMsg02, 3)


## ----readcsv02, collapse=T, tidy=FALSE-----------------------------------
datMsg03 <- 
  read.csv(file='dat.csv', row.names=1, stringsAsFactors=FALSE)
all.equal(datMsg, datMsg03)


## ----exercise01, error=TRUE, tidy=FALSE----------------------------------
dat01 <- read.csv('서울시 한강공원 이용객 현황 (2009_2013년).csv', 
                  fileEncoding = 'UTF-8')


## ----error=TRUE, tidy=FALSE----------------------------------------------
dat02 <- read.csv('서울특별시 공공자전거 대여소별 이용정보(월간)_2017_1_12.csv')
head(dat02, n=3)


## ----exercise011, error=TRUE, tidy=FALSE, eval=FALSE---------------------
## dat03 <- read.csv(
##   "http://www.nber.org/data/population-birthplace-diversity/JoEG_BP_diver
## sity_data.csv")
## head(dat03, n=3)
## ##      country_name.ccode.year.div1_a.div1_s.div1_u.div2_a.div2_s.div2_u
## ## 1 Afghanistan;AFG;1990;.0196283;.043451;.019022;.6398162;.5717307;.640
## ## 2   Albania;ALB;1990;.0700942;.0445751;.0726081;.1676445;.2764547;.160
## ## 3        Algeria;DZA;1990;.0121732;.0115634;.0121949;.58781;.5485816;.

## ----exercise012, error=TRUE, tidy=FALSE, include=FALSE------------------
dat03 <- read.csv(
  "http://www.nber.org/data/population-birthplace-diversity/JoEG_BP_diversity_data.csv")
head(dat03, n=3)


## ----fread, eval=FALSE---------------------------------------------------
## readr::read_delim(file= , delim= , col_names= )
## data.table::fread(file= , sep= , header= )


## ---- echo=F-------------------------------------------------------------
lns <- readr::read_file('UTF-8test.txt')


## ---- eval=F, tidy=FALSE-------------------------------------------------
## dat1 <- read.table('UTF-8test.txt',
##                    sep=',',
##                    fileEncoding='UTF-8',
##                    stringsAsFactors=FALSE); dat1
## dat2 <- readr::read_delim('UTF-8test.txt',
##                           delim=',',
##                           col_names=FALSE); dat2
## dat3 <- data.table::fread('UTF-8test.txt',
##                           sep=',',
##                           header=FALSE,
##                           encoding='UTF-8'); dat3


## ------------------------------------------------------------------------
dat1 <- read.table('UTF-8test.txt', 
                   sep=',', 
                   fileEncoding='UTF-8',
                   stringsAsFactors=FALSE); dat1


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## dat2 <- readr::read_delim('UTF-8test.txt',
##                           delim=',',
##                           col_names=FALSE)
## dat2
## ## Parsed with column specification:
## ## cols(
## ## X1 = col_character(),
## ## X2 = col_character(),
## ## X3 = col_character()
## ## )
## ## Warning in rbind(names(probs), probs_f): number of columns of result
## ## is not a multiple of vector length (arg 1)
## ## Warning: 5 parsing failures.
## ## row # A tibble: 5 x 5 col row col expected actual file expected
## ## ...
## ### A tibble: 2 x 3
## ##  X1                 X2               X3
## ##  <chr>              <chr>            <chr>
## ##1 création d'un rôle "ÿ\"\r\n\"初演"  重役
## ##2 초연               "\"중역\"이라고" NA


## ---- tidy=FALSE---------------------------------------------------------
dat3 <- data.table::fread('UTF-8test.txt', 
                          sep=',', 
                          header=FALSE, 
                          encoding='UTF-8'); dat3


## ---- eval=FALSE, tidy=FALSE---------------------------------------------
## dat1$V1
## dat3$V1
## 
## ## [1] "creation d'un role" "初演"               "초연"
## ## [1] "création d'un rôle" "初演"               "초연"


## ---- tidy=FALSE, eval=FALSE---------------------------------------------
## dat3df <- as.data.frame(dat3); dat3tb <- tibble::as_tibble(dat3)
## print(dat3df); print(dat3df$V1)
## 
## ##                   V1           V2
## ## 1 creation d'un role          "y"
## ## 2               初演         重役
## ## 3               초연 "중역"이라고
## ## [1] "création d'un rôle" "初演"               "초연"
## 
## print(dat3tb); print(dat3tb$V1)
## 
## ## # A tibble: 3 x 2
## ##   V1                 V2
## ## <chr>              <chr>
## ## 1 création d'un rôle "\"ÿ\""
## ## 2 初演               重役
## ## 3 초연               "\"중역\"이라고"
## ## [1] "création d'un rôle" "初演"               "초연"


## ----excel, eval=FALSE---------------------------------------------------
## readxl::excel_sheets(path= )
## readxl::read_excel(path= , sheet= )


## ----exerciese_excel, error=TRUE, eval=F---------------------------------
## library(readxl)
## readxl::read_excel('서울시 한강공원 이용객 현황 (2009_2013년).xls', sheet=1)
## ## Error in read_fun(path = path, sheet = sheet, limits = limits, shim =
## ##  Evaluation error: path[1]=" 서울시 한강공원 이용객 현황 (2009_2013 년
## ##  ).xls": 지정된 파일을 찾을 수 없습니다.


## ---- eval=F-------------------------------------------------------------
## library(readxl)
## 
## rm(list=ls())
## 
## fn = "excel_example.xls"
## vSh <- excel_sheets(fn)
## 
## #li <- vector(mode="list", length=length(vSh)-1)
## if ( length(vSh) > 0 ) {
##   for (iSh in 1:(length(vSh))) {
##     vname <- vSh[iSh]
##     if (exists(vname)) {
##       cat('\b\b변수 ', vname, '이(가) 이미 존재합니다.\n')
##       break
##     }
##     assign(vname, read_excel(fn, sheet=vSh[iSh]))
##   }
## } else {
##   cat('No Sheet!!!\n')
## }
## 
## vSh

## ---- echo=F-------------------------------------------------------------
library(readxl)

#rm(list=ls())

fn = "excel_example.xls"
vSh <- excel_sheets(fn)

#li <- vector(mode="list", length=length(vSh)-1)
if ( length(vSh) > 0 ) {
  for (iSh in 1:(length(vSh))) {
    vname <- vSh[iSh]
    if (exists(vname)) {
      cat('\b\b변수 ', vname, '이(가) 이미 존재합니다.\n')
      break
    }
    assign(vname, read_excel(fn, sheet=vSh[iSh]))
  }
} else {
  cat('No Sheet!!!\n')
}

vSh

## ----eval=F--------------------------------------------------------------
## ls()

## ----echo=F--------------------------------------------------------------
ls(pattern='(FirstSheet|fn|iSh|Ketchup|Tomato|vname|vSh)')


## ----eval=F--------------------------------------------------------------
## library(foreign)
## read.spss() # SPSS
## read.dta() # Stata
## read.ssd() # SAS
## read.octave() # Octave
## read.mtp() # Minitab
## read.systat() # Systat


## ----eval=F--------------------------------------------------------------
## library(haven)
## read_dta() # Stata
## read_por() # SPSS .por
## read_sas() # SAS
## read_sav() # SPSS .sav, .zsav
## read_stata() # Stata
## read_xpt() # SAS transport files


## ----eval=FALSE, tidy=FALSE----------------------------------------------
## url = 'http://www.nber.org/data/population-birthplace-diversity/JoEG_BP_di
## versity_data.dta'


## ----htmltab, cache=TRUE, eval=FALSE, tidy=FALSE-------------------------
## library(htmltab)
## 
## url <-
##   "https://en.wikipedia.org/wiki/List_of_most_common_surnames_in_Europe"
## surnames <- htmltab(doc = url, which = 13)
## head(surnames, n=10)


## ----readHTMLTable, cache=TRUE, eval=F, tidy=FALSE-----------------------
## library(XML)
## library(RCurl) # install.packages("RCurl")
## library(rlist)
## 
## url <-
##   "https://en.wikipedia.org/wiki/List_of_most_common_surnames_in_Europe"
## theurl <- getURL(url, .opts = list(ssl.verifypeer = FALSE) )
## df <- readHTMLTable(theurl, header = TRUE, which = 13,
##                     stringsAsFactors = FALSE, encoding = "UTF-8")
## head(df, n=10)


## ----eval=FALSE, include=FALSE-------------------------------------------
## 
## ---
## 
## ### 참고자료 {-}
## 
## * <https://cran.r-project.org/doc/manuals/R-data.pdf>

